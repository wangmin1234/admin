module.exports = {
  presets: [
    '@vue/app',
    "@vue/babel-preset-jsx"
  ]
}
