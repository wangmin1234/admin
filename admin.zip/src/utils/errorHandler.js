import Vue from 'vue'
import store from '@/store'

if (process.env.NODE_ENV === 'production') {
  Vue.config.errorHandler = function errHandler(err) {
    store.commit('addError', err)
  }
}

