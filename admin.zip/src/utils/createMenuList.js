'use strict'
import _ from 'lodash'

const checkRole = (routeRole, role) => {
  return _.intersection(routeRole, role).length !== 0
}

export default function createMenuList(routes, role) {
  const filterRoutes = routes.find((item) => {
    return item.name === 'default'
  })
  .children
  .filter((item) => {
    return !item.hidden
  })
  
  const findRoleRoutes = (routes) => {
    const list = []
    routes.forEach((item) => {
      if (!item.hidden && checkRole(item.meta.role, role)) {
        const obj = {
          title: item.meta.title,
          icon: item.meta.icon,
          name: item.name
        }
        if(item.children && item.children.length !== 0) {
          const c = findRoleRoutes(item.children)
          if(c.length !== 0) {
            obj.children = c
          }
        }
        list.push(obj)
      }
    })
    return list
  }
  return findRoleRoutes(filterRoutes)
}