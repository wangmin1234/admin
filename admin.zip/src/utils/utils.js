'use strict'

export function readAsDataURL(files) {
  return Promise.all([...files].map(file => {
    return new Promise((resolve, reject) => {
      const fr = new FileReader()
      fr.onload = event => {
        resolve(event.target.result)
      }
      fr.onerror = err => {
        reject(err)
      }
      fr.readAsDataURL(file)
    })
  }))
}

// 若项目引入mock，将会对原生XMLHttpRequest对象进行修改，这里确保能使用到原生的。
export function useNativeXMLHttpReqeust(cb) {
  if (window._XMLHttpRequest) {
    const mockXMLHttpRequest = window.XMLHttpRequest
    window.XMLHttpRequest = window._XMLHttpRequest
    cb()
    window.XMLHttpRequest = mockXMLHttpRequest
  } else {
    cb()
  }
}