const getters = {
  // app
  collapse: state => state.app.isCollapse,
  errorLog: state => state.app.errorLog,
  errorNum: state => state.app.errorLog.length,
  // user
  menuList: state => state.user.menuList,
  userInfo: state => state.user.userInfo,
  role: state => state.user.role,
  // tagviews
  tags: state => state.tagViews.views,
  cacheViews: state => state.tagViews.cacheViews.map(item => item.name)
}
export default getters
