
// 后台应用状态
const app = {
  state: {
    isCollapse: false, // 侧边栏是否折叠
    errorLog: []
  },
  mutations: {
    // 开启或折叠sidebar
    openOrCloseSidebar: (state) => {
      state.isCollapse = !state.isCollapse
    },
    // 折叠 sidebar
    closeSidebar: (state) => {
      if (!state.isCollapse) {
        state.isCollapse = true
      }
    },
    // 打开 sidebar
    openSidebar: (state) => {
      if (state.isCollapse) {
        state.isCollapse = false
      }
    },
    // add error
    addError: (state, err) => {
      state.errorLog.push({
        message: `${err.message}(${window.navigator.userAgent})`,
        stack: err.stack
      })
    },
    // clear error
    clearErrorLog: (state) => {
      state.errorLog = []
    }
  }
}

export default app