import router from '@/router'

function replace(route){
  router.replace({ name: route.name, query: route.query, params: route.parmas })
}
// 标签管理
const tagViews = {
  state: {
    views: [],
    cacheViews: []
  },
  mutations: {
    // 更新views，排序后重置
    updateTagViews: (state, views) => {
      state.views = views
      const cacheViews = []
      views.forEach(item => {
        if (item.meta.keepAlive) {
          cacheViews.push(item)
        }
      })
      state.cacheViews = cacheViews
    },
    // 更新或添加标签
    updateView: (state, route) => {
      // tag 可以是undefined，undefined通过
      if (!route.name || route.meta.tag === false) {
        return
      }
      const index = state.views.findIndex(item => {
        return item.name === route.name
      })
      if (index === -1) {
        state.views.push(route)
        if (route.meta.keepAlive) {
          state.cacheViews.push(route)
        }
      } else {
        // 出现相同的替换成新的route，**会替换其中的参数等**
        state.views[index] = route
      }
    },
    // 关闭标签，根据index
    closeView: (state, index) => {
      const closeRoute = state.views[index]
      // 先删除缓存记录标识 
      state.cacheViews = state.cacheViews.filter(item => item.name !== closeRoute.name)
      state.views.splice(index, 1)
      if (closeRoute.name === router.currentRoute.name) {
        if (state.views.length === 0) {
          router.replace({path: '/'})
        } else {
          if (state.views.length - 1 >= index) {
            replace(state.views[index])
          } else {
            replace(state.views[state.views.length - 1])
          }
        }
      }
    },
    // 关闭缓存标签
    closeCacheView(state, route) {
      state.cacheViews = state.cacheViews.filter(item => item.name !== route.name)
    },
    // 关闭右侧标签
    closeRightViews(state, index) {
      const routeNames = state.views.splice(index + 1).map(item => item.name)
      state.cacheViews = state.cacheViews.filter(item => routeNames.indexOf(item.name) < 0)
      const res = state.views.find(item => {
        return item.name === router.currentRoute.name
      })
      if (!res) {
        router.push({ ...state.views[state.views.length - 1] })
      }
    },
    // 关闭其它标签
    closeOtherViews: (state, route) => {
      state.cacheViews = state.cacheViews.filter((item) => {
        return item.name === route.name
      })
      state.views = state.views.filter((item) => {
        return item.name === route.name
      })
      const uniqueRoute = state.views[0]
      if (router.currentRoute.name !== uniqueRoute.name) {
        replace(uniqueRoute)
      }
    },
    // 关闭所有标签
    closeAllViews: (state) => {
      state.cacheViews = []
      state.views = []
      router.replace({path: '/'})
    }
  }
}

export default tagViews