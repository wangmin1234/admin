
const user = {
  state: {
    userInfo: null,
    role: [],
    menuList: []
  },
  mutations: {
    userInit(state, { userInfo, role, menuList}){
      state.userInfo = userInfo
      state.role = role
      state.menuList = menuList
    }
  }
}

export default user

