import Vue from 'vue'
import Vuex from 'vuex'

import app from './module/app'
import user from './module/user'
import tagViews from './module/tagViews'

import getters from './getters'

Vue.use(Vuex)

const store = new Vuex.Store({
  modules: {
    app,
    user,
    tagViews
  },
  getters
})




export default store