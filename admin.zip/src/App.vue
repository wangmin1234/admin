<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>


export default {
  name: 'app'
}
</script>
<style lang="less">
  html {
    height: 100%;
  }
  body {
    height: 100%;
    font-family: "Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","微软雅黑",Arial,sans-serif;
    // overflow-x: hidden;
    // 防止页面切换动画出现横线滚动条
  }
  #app {
    min-height: 100%;
  }
</style>

