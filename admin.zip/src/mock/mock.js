
import Vue from 'vue'
import Mock from 'mockjs'
Vue.prototype.$Mock = Mock
Vue.prototype.$Random = Mock.Random


// 设置ajax请求延时响应
Mock.setup({ timeout: '200-600' })


// 登录
Mock.mock(/\/login$/, 'post', {
  status: 200,
  data: 'authorizationdata',
})

// 获取用户信息（可访问的路由表）
Mock.mock(/\/getUserInfo$/, 'post', {
  status: 200,
  data: {
    role: ['merchant'],
    userInfo: {
      name: '@name',
      pic: Mock.Random.image('100x100')
    }
  }
})

