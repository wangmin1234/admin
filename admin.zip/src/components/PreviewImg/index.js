import Vue from 'vue'
import previewImg from './previewImg'

const PreviewImg = Vue.extend(previewImg)

let instance = null
const getInstance = function getInstanceF() {
  if (instance) {
    return instance
  }
  instance = new PreviewImg({
    el: window.document.createElement('div')
  })
  window.document.body.appendChild(instance.$el)
  return instance
}

export const previewImgHandle = function _previewImg({src}) {
  const instance = getInstance()
  instance.preview({src})
}

export default function install(Vue) {
  Vue.prototype.$previewImg = previewImgHandle
}