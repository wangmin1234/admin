
<template>
  <div class="preview-img-wrap">
    <el-dialog :visible.sync="show">
      <img class="picture" :src="src" alt="图片">
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      show: false,
      src: ''
    }
  },
  methods: {
    preview({src}) {
      this.src = src
      this.show = true
    }
  }
};
</script>

<style lang="less">
  .preview-img-wrap {
    .el-dialog__wrapper {
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .el-dialog {
      margin: auto!important;
      width: auto;
      height: auto;
      max-width: 50%;
      max-height: 80%;
      box-shadow: none!important;
      .el-dialog__header {
        display: none;
      }
      .el-dialog__body {
        width: 100%;
        height: 100%;
        padding: 0;
      }
      .picture {
        max-width: 100%;
        max-height: 100%;
      }
    }
  }
</style>
