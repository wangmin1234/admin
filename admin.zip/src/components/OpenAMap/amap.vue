<template>
  <el-dialog
  :visible.sync="showAMapDialog"
  width="80%"
  class="amap-dialog"
  >
  <div class="amap-wrap2">
    <el-amap ref="amap" :zoom="zoom" :center="center"></el-amap>
  </div>
  </el-dialog>
</template>

<script>
export default {
  data() {
    return {
      showAMapDialog: true,
      zoom: 12,
      center: []
    }
  }
};
</script>

<style lang="less">
  .amap-dialog {
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 0;
    }
    .amap-wrap2 {
      height: 500px;
      max-height: 75vh;
    }
  }
</style>
