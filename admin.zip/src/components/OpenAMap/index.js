import Vue from 'vue'
import amap from './amap'

const AMap = Vue.extend(amap)

let instance = null
const getInstance = function getInstanceF() {
  if (instance) {
    return instance
  }
  instance = new AMap({
    el: window.document.createElement('div')
  })
  window.document.body.appendChild(instance.$el)
  return instance
}

const aMapHandle = function _amap({zoom = 12, center}) {
  const ins = getInstance()
  ins.zoom = zoom
  ins.center = center
  ins.showAMapDialog = true
}

export default function install(Vue) {
  Vue.prototype.$openAMap = aMapHandle
}