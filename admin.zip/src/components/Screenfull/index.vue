<template>
  <el-tooltip effect="dark" :content="!isFullscreen ? '全屏显示': '退出全屏'" placement="bottom">
    <span class="iconfont" :class="isFullscreen ? 'icon-quxiaoquanping' : 'icon-max-screen'"
    @click="click"
    ></span>
  </el-tooltip>
</template>

<script>
import screenfull from "screenfull";

export default {
  name: "Screenfull",
  data() {
    return {
      isFullscreen: false
    };
  },
  created() {
    // 监听用户使用键盘按键开启/关闭全屏
    screenfull.on("change", () => {
      if (!screenfull.isFullscreen) {
        this.isFullscreen = false;
      } else {
        this.isFullscreen = true;
      }
    });
  },
  methods: {
    click() {
      if (!screenfull.enabled) {
        this.$message({
          message: "您的浏览器不支持全屏显示",
          type: "warning"
        });
        return false;
      }
      screenfull.toggle();
    }
  }
};
</script>
