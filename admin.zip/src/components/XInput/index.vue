<template>
  <div class="x-input-wrap">
    <div class="text" :class="{bold}" v-show="!isEditing" @click="textClick">{{value}}</div>
    <div class="edit" v-show="isEditing">
      <input class="x-input" :value="value" :placeholder="placeholder" type="text" ref="xInput" @input="input($event)" @blur="cancel" @keyup.enter="confirm">
      <div class="action">
        <el-tooltip content="点击或回车保存" placement="top">
          <span class="icon icon-confirm el-icon-check" @click="confirm"></span>
        </el-tooltip>
        <span class="icon icon-cancel el-icon-close" title="取消" @click="cancel"></span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    store: {
      type: [String, Number, Boolean, Array, Object, Date, Function, Symbol],
      default: null
    },
    value: {
      type: String,
      default: ''
    },
    type: {
      type: String,
      default: 'text'
    },
    placeholder: {
      type: String,
      default: ''
    },
    bold: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      isEditing: false
    }
  },
  methods: {
    textClick() {
      this.isEditing = true
      this.$nextTick(() => {
        this.$refs.xInput.focus()
      })
    },
    input(event) {
      const inputValue = event.target.value
      if(this.type === 'float') {
        // 过滤出两位小数
        this.$refs.xInput.value = inputValue.match(/^\d*(\.?\d{0,2})/g)[0]
      }
      if(this.type === 'integer') {
        this.$refs.xInput.value = inputValue.match(/^\d+/g)[0]
      }
    },
    init() {
      this.isEditing = false
    },
    confirm() {
      this.$emit('change', {store: this.store, value: this.$refs.xInput.value})
      this.init()
    },
    cancel() {
      this.init()
    }
  }
};
</script>

<style scoped lang="less">
  .x-input-wrap {
    display: inline-block;
    width: 100%;
    position: relative;
    .text {
      width: 100%;
      height: 30px;
      font-size: 14px;
      padding: 0 5px;
      border: 1px solid rgba(222, 222, 222, .3);
      line-height: 30px;
      cursor: text;
      transition: border-color .3s;
      &.bold {
        font-weight: 700;
      }
      &:hover {
        border: 1px solid #409EFF;
      }
    }
    .edit {
      width: 100%;
      height: 30px;
      .x-input {
        width: 100%;
        height: 100%;
        line-height: 30px;
        padding: 0 5px;
        border: 1px solid #409EFF;
        font-size: 14px;
        color: #585a6e;
        outline: none;
      }
      .action {
        width: 60px;
        height: 30px;
        position: absolute;
        right: -60px;
        top: 0;
        z-index: 1000;
        .icon {
          width: 30px;
          height: 30px;
          line-height: 30px;
          text-align: center;
          cursor: pointer;
        }
        .icon-confirm {
          color: #fff;
          background-color: #409EFF;
        }
        .icon-cancel {
          color: #000;
          background-color: #f7f8fa;
        }
      }
    }
  }
</style>
