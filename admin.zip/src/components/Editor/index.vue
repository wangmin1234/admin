<template>
  <div class="editor-wrap">
    <div class="editor-tools" ref="editor-tools"></div>
    <div class="editor-content" ref="editor-content" :style="{height}">
    </div>
  </div>
</template>

<script>
import WangEditor from 'wangeditor'

export default {
  model: {
    prop: 'content',
    event: 'change'
  },
  props: {
    content: {
      type: String,
      required: true
    },
    height: {
      type: String,
      default: '400px'
    }
  },
  mounted(){
    this.editor = new WangEditor(this.$refs['editor-tools'], this.$refs['editor-content'])
    this.editor.customConfig.onchange = html => {
      this.$emit('change', html)
    }
    this.editor.customConfig.zIndex = 100
    this.editor.customConfig.uploadImgServer = '/load'
    this.editor.create()
    this.editor.txt.html(this.content)
  },
  watch: {
    content(val){
      this.editor.txt.html(val)
    }
  }
};
</script>

<style lang="less">
  .editor-wrap {
    .editor-tools {
      background-color: #fff!important;
      margin-bottom: 15px;
      border: 1px solid rgba(222, 222, 222, .6);
    }
    .editor-content {
      font-size: 16px;
      border: 1px solid rgba(222, 222, 222, .6);
      height: 400px;
    }
  }
</style>
