import { MessageBox} from 'element-ui'

const defaultMessage = '发生预期之外的错误，请稍后再试或通知管理员。'

const errorAlert = function alert({ msg = defaultMessage} = {}) {
  MessageBox.alert(msg, '错误提示', {
    showCancelButton: false,
    dangerouslyUseHTMLString: true
  }).then(() => {}).catch(() => {})
}

export default function install(Vue) {
  Vue.prototype.$errorAlert = errorAlert
}