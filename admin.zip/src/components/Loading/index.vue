<template>
  <div class="view-loading-wrap">
    <h1 class="title">loading...</h1>
  </div>
</template>
<style scoped lang="less">
  .view-loading-wrap {
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #fff;
    .title {
      font-size: 20px;
      color: #ccc;
      user-select:none;
    }
  }
</style>
