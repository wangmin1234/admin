<template>
  <el-dialog 
  :visible.sync="show"
  class="cropper-dialog"
  width="100%"
  :close-on-click-modal="false"
  :close-on-press-escape="false"
  :before-close="beforeClose"
  title="图片裁剪"
  >
    <!-- 大图区域 -->
    <div class="master-wrap clearfix">
      <div class="picture-content">
        <div class="picture-wrap">
          <img class="picture" ref="picture" :src="imgUrl">
        </div>
        <div class="desc-bar">
          <span class="size">{{scale ? scale : 'free'}}</span>
          <div class="adjustment-wrap">
            <span>{{Number(zoom * 100).toFixed(0) + '%'}}</span>
          </div>
        </div>
      </div>
    </div>
    <!-- 右侧操作区 -->
    <div class="functional-wrap">
      <div class="preview-wrap" ref="previewWrap">
        <div class="preview" ref="preview"></div>
      </div>
      <div class="reversal-btns">
        <el-button plain @click.native="flipHorizontal">
          <span class="iconfont icon-shuipingfanzhuan1"></span>
          <span>水平翻转</span>
        </el-button>
        <el-button plain @click.native="flipVertical">
          <span class="iconfont icon-chuizhifanzhuan2"></span>
          <span>垂直翻转</span>
        </el-button>
      </div>
      <el-button class="submit" type="primary" @click.native="done('success')">完成</el-button>
    </div>
  </el-dialog>
</template>

<script>
import Cropper from 'cropperjs'
import {useNativeXMLHttpReqeust} from '@/utils/utils'

import 'cropperjs/dist/cropper.min.css'

export default {
  name: 'cropper',
  data() {
    return {
      show: false,
      zoom: 1,

      imgUrl: '',
      scale: null,
      calculatedScale: null
    }
  },
  methods: {
    init({imgUrl, scale}) {
      this.imgUrl = imgUrl
      this.scale = scale
      this.initCropper()
    },
    initCropper() {
      const _initCropper = () => {
        this.setCalculatedScale()
        this.initPreviewWrap()
        const picture = this.$refs.picture
        useNativeXMLHttpReqeust(() => {
          if(this.cropper) {
            this.cropper.destroy()
          }
          this.cropper = new Cropper(picture, {
            viewMode: 2,
            aspectRatio: this.calculatedScale || NaN,
            // 禁止图片移动
            movable: false,
            preview: this.$refs.preview,
            ready: () => {
              const {width, naturalWidth} = this.cropper.getImageData()
              this.zoom = width / naturalWidth
            },
            zoom: event => {
              this.zoom = event.detail.ratio
            }
          })
        })
        this.initEventListener()
      }
      if(!this.show) {
        this.show = true
        this.$nextTick(_initCropper)
      } else {
        _initCropper()
      }
    },
    initPreviewWrap(){
      const {clientWidth, clientHeight} = this.$refs.previewWrap
      const scale = this.calculatedScale
      const preview = this.$refs.preview

      const previewWrapScale = clientWidth / clientHeight

      if(previewWrapScale >= scale) {
        preview.style.height = clientHeight + 'px'
        preview.style.width = clientHeight * scale + 'px'
      } else {
        preview.style.width = clientWidth + 'px'
        preview.style.height = clientWidth / scale + 'px'
      }
    },
    setCalculatedScale() {
      try {
        if(!this.scale) {
          this.calculatedScale = null
          return
        }
        const arr = this.scale.split(':')
        this.calculatedScale = arr[0] / arr[1]
      }catch(e) {
        throw new Error(`图片比例格式错误。eg: '1:1'`)
      }
    },
    initEventListener() {
      this.updateCropper = this.$_.debounce(() => {
        if(this.cropper) {
          this.initCropper()
        }
      }, 400)
      window.addEventListener('resize', this.updateCropper)
    },
    flipHorizontal() {
      // 水平翻转
      if(this.cropper) {
        const {scaleX} = this.cropper.getData()
        if(scaleX === 1) {
          this.cropper.scaleX(-1)
        } else {
          this.cropper.scaleX(1)
        }
      }
    },
    flipVertical() {
      // 垂直翻转
      if(this.cropper) {
        const {scaleY} = this.cropper.getData()
        if(scaleY === 1) {
          this.cropper.scaleY(-1)
        } else {
          this.cropper.scaleY(1)
        }
      }
    },
    beforeClose() {
      this.done('cancel')
    },
    done(action) {
      if(!this.cropper) {
        return
      }
      if(this.callback) {
        this.callback(action, {path: this.cropper.getCroppedCanvas().toDataURL('image/png')})
      }
      this.cropper.destroy()
      this.cropper = null
      window.removeEventListener('resize', this.updateCropper)
      
      this.imgUrl = ''
      this.scale = null
      this.calculatedScale = null
      this.show = false
    }
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.updateCropper)
  }
};
</script>

<style lang="less">
.cropper-dialog {
  display: flex;
  justify-content: center;
  align-items: center;
  .el-dialog {
    max-width: 1200px!important;
    min-width: 992px!important;
    margin: 0!important;
    padding-bottom: 20px;
    .el-dialog__header {
      padding: 10px 20px;
    }
    .el-dialog__body {
      height: 100%;
      height: 550px;
      padding: 0 20px;
      .master-wrap {
        width: 75%;
        height: 100%;
        float: left;
        background-color: #f1f2f4;
        display: flex;
        align-items: center;
        .iconfont {
          color: #dfdfe0;
          text-align: center;
          cursor: pointer;
          &:hover {
            color: #ccc
          }
        }
        .picture-content {
          background-size:100% 100%;
          flex: 8;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          align-items: center;
          height: 100%;
          overflow: hidden;
          .picture-wrap {
            width: 100%;
            height: 90%;
            .picture {
              max-width: 100%;
            }
          }
          .desc-bar {
            height: 7%;
            background-color: rgba(0, 0, 0, 0.7);
            border-radius: 50px;
            padding: 0 30px;
            display: flex;
            justify-content: space-around;
            align-items: center;
            color: #fff;
            margin-bottom: 8px;
            .size {
              margin-right: 30px;
              color: #8c8c8c;
            }
            .adjustment-wrap {
              color: #dadbdb;
              .iconfont {
                font-size: 12px;
                margin: 0 12px;
                font-weight: 700;
              }
            }
          }
        }
      }
      .functional-wrap {
        width: 25%;
        height: 100%;
        float: left;
        padding-left: 20px;
        padding-bottom: 10px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: space-between;
        .preview-wrap {
          width: 100%;
          height: 34%;
          display: flex;
          justify-content: center;
          align-items: flex-start;
          background-color: #f1f2f4;
          .preview {
            overflow: hidden;
          }
        }
        .reversal-btns {
          margin-top: 20px;
          .el-button {
            width: 100%;
            margin-left: 0;
            & + .el-button {
              margin-top: 10px;
            }
          }
          .iconfont {
            margin-right: 5px;
          }
        }
        .submit {
          width: 100%;
          margin-top: 20px;
        }
      }
    }
  }
}
</style>

