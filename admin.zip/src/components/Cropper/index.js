import Vue from 'vue'
import cropper from './cropper'

const Cropper = Vue.extend(cropper)

let instance = null
const getInstance = function getInstanceF() {
  if (instance) {
    return instance
  }
  instance = new Cropper({
    el: window.document.createElement('div')
  })
  window.document.body.appendChild(instance.$el)
  return instance
}

const cropperHandle = function _cropper({imgUrl, scale} = {}) {
  const instance = getInstance()
  return new Promise((resolve, reject) => {
    instance.callback = (action, arg) => {
      if(action === 'success') {
        return resolve(arg)
      }
      if(action === 'cancal') {
        return reject()
      }
    }
    instance.init({ imgUrl, scale })
  })
}

export default function install(Vue) {
  Vue.prototype.$cropper = cropperHandle
}