<template>
  <div class="bone-screen-wrap">
    <!-- 侧边栏 -->
    <div class="b-sidebar"></div>
    <div class="b-right-wrap">
      <!-- header -->
      <div class="b-header clearfix">
        <p class="b-links stripes"></p>
        <p class="b-pic "></p>
        <p class="b-reat"></p>
        <p class="b-reat"></p>
        <p class="b-reat"></p>
      </div>
      <!-- 标签 -->
      <div class="b-tags stripes"></div>

      <div class="line line1 stripes"></div>
      <div class="line line1 stripes"></div>
      <div class="line line1 stripes"></div>
      <div class="line line1 stripes"></div>
      <div class="line line1 stripes"></div>

      <div class="line line2 stripes"></div>
      <div class="line line2 stripes"></div>
      <div class="line line2 stripes"></div>
      
    </div>
    
  </div>
</template>
<script>
import createMenuList from '@/utils/createMenuList'

export default {
  name: 'bonescreen',
  created(){
    this.$post('/getUserInfo').then(({status, data: res, msg}) => {
      if(status !== 200) {
        this.$alert(msg, '提示')
        return
      }
      const {role, userInfo} = res
      const menuList = createMenuList([...this.$router.options.routes], role)
      this.$store.commit('userInit', {menuList, role, userInfo})
      const skipRoute = JSON.parse(window.localStorage.getItem('skipRoute'))
      if(skipRoute) {
        window.localStorage.removeItem('skipRoute')
        this.$router.replace({path: skipRoute.fullPath, params: skipRoute.params, query: skipRoute.query})
      }else {
        this.$router.replace({path: '/'})
      }
    })
    .catch( () => {
      this.$alert('获取用户信息发送错误，截图该页面反馈。', '错误')
    })
  }
}
</script>

<style scoped lang="less">
  @bg1:#f9f9f9;
  @bg2:#ecebeb;

  @keyframes stripes {
    0% {
      background-position: -700px 0;
    }
    100% {
      background-position: 700px 0;
    }
  }
  .stripes {
    border-radius: 3px;
    background-repeat: no-repeat;
    background-image: linear-gradient(to right, @bg1 0%, @bg1 8%,@bg2 24%, @bg1 50%, @bg2 65%, @bg1 80%);
    animation-name: stripes;
    background-color: @bg1;
    animation-duration: 3s;
    animation-iteration-count: infinite;
    animation-timing-function: linear;
  }

  .bone-screen-wrap {
    width: 100%;
    height: 100%;
    background-color: #fff;
    .b-sidebar {
      width: 180px;
      height: 100%;
      float: left;
      margin-right: 20px;
    }
    .b-right-wrap {
      overflow: hidden;
      .b-header {
        margin-top: 40px;
        padding: 20px 20px 20px 0;
        background-color: #fff;
        .b-links {
          width: 500px;
          height: 15px;
          float: left;
        }
        .b-reat {
          width: 40px;
          height: 20px;
          float: right;
          margin-right: 25px;
          margin-top: 5px;
          background-color: @bg1;
        }
        .b-pic {
          width: 30px;
          height: 30px;
          border-radius: 50%;
          float: right;
          background-color: @bg1;
        }
      }
      .b-tags {
        width: 300px;
        height: 12px;
        margin-top: 10px;
        margin-bottom: 100px;
      }
      .line {
        + .line {
          margin-top: 30px;
        }
        &.line1 {
          width: 1000px;
          height: 10px;
        }
        &.line2 {
          width: 600px;
          height: 10px;
        }
      }
      
    }
  }
</style>
