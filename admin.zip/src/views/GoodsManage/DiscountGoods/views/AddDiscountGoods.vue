<template>
  <edit-discount-goods></edit-discount-goods>
</template>

<script>
import EditDiscountGoods from '../components/EditDiscountGoods'

export default {
  components: {EditDiscountGoods},
  data() {
    return {}
  }
};
</script>

<style scoped>

</style>
