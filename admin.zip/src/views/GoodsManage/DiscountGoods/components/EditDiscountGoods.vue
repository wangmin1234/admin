<template>
  <div class="edit-discount-goods">
    <el-form :model="discountGoods" class="discount-goods-form" label-width="120px" label-position="left">
      <!-- 商品图片 -->
      <el-form-item label="商品名称" prop="goodsName" :rules="[
        {
          required: true,
          message: '填写正确的低折扣商品名称（30字以内）',
          max: 30
        }
      ]">
        <el-input v-model="discountGoods.goodsName" placeholder="输入商品名称"></el-input>
      </el-form-item>
      <!-- 商品图片 -->
      <el-form-item label="商品图片" class="upload-goods-pic" :rules="[
        {
          required: true
        }
      ]">
        <p class="tip">商品图片尺寸：600x450</p>
        <div class="goods-pic-wrap">
          <span class="icon-add-pic el-icon-plus"></span>
        </div>
      </el-form-item>
      <!-- 商品原价 -->
      <el-form-item label="商品原价" prop="goodsOldPrice" :rules="[
        {
          required: true,
          message: '请填写正确的商品原价',
          pattern: /^\d+(\.\d{1,2})?$/
        }
      ]">
        <el-input v-model="discountGoods.goodsOldPrice" placeholder="输入商品原价"></el-input>
      </el-form-item>
      <!-- 商品折扣价 -->
      <el-form-item label="商品折扣价" prop="goodsPrice" :rules="[
        {
          required: true,
          message: '填写正确的商品原价',
          pattern: /^\d+(\.\d{1,2})?$/
        }
      ]">
        <el-input v-model="discountGoods.goodsPrice" placeholder="输入商品折扣价"></el-input>
      </el-form-item>
      <!-- 起购数量 -->
      <el-form-item label="起购数量" prop="purNum" :rules="[
        {
          required: true,
          message: '输入正确的起购数量',
          pattern: /^\d+$/
        }
      ]">
        <el-input v-model="discountGoods.purNum" placeholder="输入起购数量"></el-input>
      </el-form-item>
      <!-- 商品描述 -->
      <el-form-item label="商品详情" class="goods-details" prop="details" :rules="[
        {
          required: true,
          message: '输入正确的商品详情'
        }
      ]">
        <editor v-model="discountGoods.details"></editor>
      </el-form-item>
    </el-form>
    <div class="footer-action">
      <el-button type="primary">保存并返回</el-button>
      <el-button type="primary">保存并继续新建</el-button>
      <el-button type="warning" plain>取消</el-button>
    </div>
  </div>
</template>

<script>
import Editor from '@/components/Editor'

export default {
  components: {Editor},
  data() {
    return {
      discountGoods: {
        goodsName: '',
        goodsOldPrice: '',
        goodsPrice: '',
        purNum: '',
        details: ''
      }
    }
  }
};
</script>

<style scoped lang="less">
  .edit-discount-goods {
    width: 100%;
    background-color: #fff;
    padding: 15px;
    max-width: 95%;
    .discount-goods-form {
      width: 550px;
      .tip {
        font-size: 12px;
        color: rgb(133, 134, 146);
        margin-bottom: 5px;
      }
      .upload-goods-pic {
        .goods-pic-wrap {
          width: 120px;
          height: 90px;
          background-color: rgb(246, 246, 246);
          cursor: pointer;
          color: rgb(133, 134, 146);
          .icon-add-pic {
            display: inline-block;
            width: 100%;
            height: 100%;
            font-size: 28px;
            text-align: center;
            line-height: 90px;
          }
        }
      }
      .goods-details {
        width: 1200px;
      }
    }
    .footer-action {
      margin-top: 50px;
      text-align: right;
      padding-bottom: 30px;
    }
  }
</style>
