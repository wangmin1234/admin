<template>
  <div class="">
    <h1>低折扣商品</h1>
  </div>
</template>

<script>
export default {
  data() {
    return {}
  }
};
</script>

<style scoped>

</style>
