import Mock, {Random} from 'mockjs'

export function getAllShareGoods() {
  return new Array(5).fill(1).map(() => {
    return Mock.mock({
      pic: Random.dataImage('600x450', 'pic'),
      goodsName: Random.cword(5, 10),
      num: Random.integer(1, 20),
      spe: '规格' + Random.integer(1, 10),
      price: Random.float(500, 2000, 2, 2),
      shopName: Random.cword(5, 10),
      shopNameLinkman: Random.cword(3),
      phone: Random.id(),
      // type 0 我的共享商品  1 可申请 2 申请中 3 通过申请 4 未通过申请 5 由我审核
      type: Random.integer(0, 5),
      status: Random.integer(0, 1),
      period: function() {
        const random = Random.integer(1, 5)
        const arr = []
        for(let i = 0; i < random; i++) {
          arr.push(Mock.mock({
            startTime: Random.datetime('yyyy-MM-dd HH:mm:ss'),
            endTime: Random.datetime('yyyy-MM-dd HH:mm:ss'),
            num: Random.integer(1, 10)
          }))
        }
        return arr
      }
    })
  })
}