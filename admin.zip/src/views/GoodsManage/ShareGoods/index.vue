<template>
  <div class="share-goods-wrap">
    <el-radio-group class="select-wrap" v-model="type">
      <el-radio :label="0">我的共享商品</el-radio>
      <el-radio :label="1">可申请的</el-radio>
      <el-radio :label="2">申请中的</el-radio>
      <el-radio :label="3">申请通过的</el-radio>
      <el-radio :label="4">申请失败的</el-radio>
      <el-radio :label="5">由我审核</el-radio>
    </el-radio-group>
    <!-- 我的共享商品 -->
    <template v-if="type === 0">
      <div class="select-wrap">
        <el-radio-group v-model="myShareGoodsStatus">
          <el-radio :label="1">启用</el-radio>
          <el-radio :label="0">未启用</el-radio>
        </el-radio-group>
        <el-button style="margin-left: 20px;" type="primary" size="small">新增共享商品</el-button>
      </div>
    </template>

    <!-- 可申请的 -->
    <template v-if="type === 1">
      <div class="select-wrap">
        <el-checkbox v-model="checkAll">全选本页</el-checkbox>
        <el-button type="primary" plain size="small">批量申请</el-button>
      </div>
    </template>

    <!-- 申请中的 -->
    <template v-if="type === 2">
      <div class="select-wrap">
        <el-checkbox>全选本页</el-checkbox>
        <el-button type="primary" plain size="small">批量撤销</el-button>
      </div>
    </template>

    <!-- 由我审核 -->
    <template v-if="type === 5">
      <div class="select-wrap">
        <el-checkbox>全选本页</el-checkbox>
        <el-button type="primary" plain size="small">批量通过</el-button>
      </div>
    </template>

    <share-goods-item v-for="(item, index) in goodsData" :key="index" :goods="item"></share-goods-item>

    <el-pagination class="pagination-wrap" :total="50" layout="prev, pager, next"></el-pagination>
  </div>
</template>

<script>
import ShareGoodsItem from './components/ShareGoodsItem'
import { getAllShareGoods} from './mock'

export default {
  components: {ShareGoodsItem},
  data() {
    return {
      type: 0,
      myShareGoodsStatus: 1,
      goodsData: [],
      checkAll: false
    }
  },
  created() {
    this.goodsData = getAllShareGoods()
  }
};
</script>

<style scoped lang="less">
  .share-goods-wrap {
    width: 100%;
  }
</style>
