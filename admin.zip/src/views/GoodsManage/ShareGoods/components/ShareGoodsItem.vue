<template>
  <div class="share-goods-item clearfix">
    <div class="details">
      <div class="goods-pic-wrap">
        <img class="goods-pic" :src="goods.pic" alt="图片">
        <el-checkbox class="g-checkbox"></el-checkbox>
      </div>
      <div class="goods-info clearfix">
        <div class="base">
          <h3 class="name">{{goods.goodsName}}</h3>
          <p class="num-spe">x {{goods.num}} 份 &nbsp;&nbsp; {{goods.spe}}</p>
          <p class="price"><span class="u">￥</span> {{goods.price}}</p>
        </div>
        <div class="goods-shop-info">
          <h4 class="shop-name" title="商品所属店铺">{{goods.shopName}}</h4>
          <p class="linkman">{{goods.shopNameLinkman}}： {{goods.phone}}</p>
        </div>
        <div class="goods-actions">
          <!-- 我的共享商品 -->
          <template v-if="goods.type === 0">
            <el-button v-if="goods.status === 0" type="primary" size="small">启用</el-button>
            <el-button v-if="goods.status === 1" type="text" size="small" plain>下架</el-button>
            <el-button type="text" size="small" plain>编辑</el-button>
            <el-button type="text" size="small" plain>删除</el-button>
          </template>
          <!-- 可申请的共享商品 -->
          <el-button v-if="goods.type === 1" type="primary" size="small">申请</el-button>
          <!-- 申请中的 -->
          <el-button v-if="goods.type === 2" type="text" size="small" plain>撤销</el-button>
          <!-- 申请失败的 -->
          <el-button v-if="goods.type === 4" type="text" size="small" plain>重新申请</el-button>
          <!-- 由我审核 -->
          <template v-if="goods.type === 5">
            <el-button type="primary" size="small">通过</el-button>
            <el-button type="primary" plain size="small">拒绝</el-button>
          </template>
        </div>
      </div>
    </div>
    
    <div class="goods-steps-wrap">
      <el-button type="text" size="small" v-if="!showSteps" @click="showSteps = true">展开使用周期</el-button>
      <el-steps class="goods-steps" :active="-1" v-if="showSteps">
        <el-step v-for="(item, index) in goods.period" :key="index" title="周期">
          <div class="step-item-desc" slot="description">
            <p>x {{item.num}}</p>
            <p>{{item.startTime}}</p>
            <p><span class="el-icon-sort-down"></span></p>
            <p>{{item.endTime}}</p>
          </div>
        </el-step>
      </el-steps>
    </div>
    
  </div>
</template>

<script>
export default {
  props: {
    goods: {
      type: Object
    }
  },
  data() {
    return {
      showSteps: false,
    }
  },
  methods: {
  }
};
</script>

<style scoped lang="less">
  .share-goods-item {
    background-color: #fff;
    padding: 15px;
    margin-top: 20px;
    .details {
      width: 100%;
      .goods-pic-wrap {
        float: left;
        width: 120px;
        height: 90px;
        margin-right: 20px;
        position: relative;
        .goods-pic {
          max-width: 100%;
          max-height: 100%;        
        }
        .g-checkbox {
          position: absolute;
          top: -10px;
          left: 0;
          z-index: 10;
        }
      }
      .goods-info {
        overflow: hidden;
        .base {
          width: 35%;
          float: left;
          .name {
            font-size: 16px;
            font-weight: 700;
          }
          .num-spe {
            font-size: 12px;
            color: #a2a4b3;
            margin-top: 8px;
          }
          .price {
            font-size: 14px;
            margin-top: 10px;
            font-weight: 700;
            color: #409EFF;
            .u {
              font-size: 12px;
              color: #a2a4b3;
              font-weight: 400;
            }
          }
        }
      }
      .goods-shop-info {
        width: 35%;
        float: left;
        margin-left: 5%;
        .shop-name {
          font-size: 16px;
        }
        .linkman {
          font-size: 14px;
          margin-top: 10px;
        }
        .tip {
          font-size: 12px;
          color: #F56C6C;
          margin-top: 5px;
        }
      }
      .goods-actions {
        width: 20%;
        margin-left: 5%;
        float: left;
        text-align: right;
        padding-right: 30px;
        .tip {
          font-size: 12px;
          color: #F56C6C;
        }
      }
    }
    .goods-steps-wrap {
      width: 100%;
      margin-top: 40px;
    }
  }
</style>
