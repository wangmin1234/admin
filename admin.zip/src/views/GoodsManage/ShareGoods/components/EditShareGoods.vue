<template>
  <div class="edit-share-goods">
    <div class="search-box">
      <div class="title">
        <span class="t">搜索本店商品</span>
        <el-button type="primary" plain size="small">添加商品</el-button>
      </div>
      <el-autocomplete class="search-input" v-model="searchText" placeholder="输入搜索本店商品名" :fetch-suggestions="querySearchFetch"></el-autocomplete>
    </div>
    
    <!-- 表单 -->
    <el-form :model="shareGoods" class="share-goods-form" label-width="120px" label-position="left">
      <!-- 商品图片 -->
      <el-form-item label="商品图片" class="goods-pic">
        <img class="pic" :src="goodsPic" alt="图片">
      </el-form-item>
      <!-- 商品价格 -->
      <el-form-item label="商品价格">
        <el-input v-model="goodsPrice" disabled></el-input>
      </el-form-item>
      <!-- 商品规格 -->
      <el-form-item label="商品规格/属性" class="goods-spe">
        <el-select v-model="shareGoods.spe" placeholder="选择商品规格/属性">
          <el-option v-for="(item, index) in spes" :key="index" :label="item" :value="item"></el-option>
        </el-select>
        <el-button class="add-spe" type="text" size="small">添加规格/属性</el-button>
      </el-form-item>
      <!-- 使用周期 -->
      <el-form-item label="商品周期" class="share-goods-period">
        <div class="period-item" v-for="item in 1" :key="item">
          <h3 class="period-label">周期1</h3>
          <div class="p-cell">
            <p class="label">周期使用时间</p>
            <el-date-picker type="datetimerange" range-separator="-" start-placeholder="开始日期" end-placeholder="结束日期"></el-date-picker>
          </div>
          <div class="p-cell">
            <p class="label">周期使用数量</p>
            <el-input></el-input>
          </div>
        </div>
        <el-button class="add-period" type="primary" size="small">添加周期</el-button>
      </el-form-item>
    </el-form>
    <div class="footer-wrap">
      <el-button type="primary">提交</el-button>
      <el-button type="primary" plain>取消</el-button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      searchText: '',
      goodsPrice: this.$Random.float(100, 200, 2, 2),
      goodsPic: this.$Random.dataImage('600x450', 'pic'),
      spes: ['a', 'b'],
      shareGoods: {

      },
    }
  },
  methods: {
    querySearchFetch(str, cb) {
      setTimeout(() => {
        cb([{ "value": "妙生活果园（北新泾店）", "address": "长宁区新渔路144号" },
          { "value": "香宜度麻辣香锅", "address": "长宁区淞虹路148号" },])
      }, 1000)
    }
  }
};
</script>

<style scoped lang="less">
  .edit-share-goods {
    width: 100%;
    background-color: #fff;
    padding: 15px;
    max-width: 95%;
    .search-box {
      max-width: 500px;
      .title {
        margin-bottom: 10px;
        .t {
          font-size: 18px;
          margin-right: 20px;
        }
      }
      .search-input {
        width: 100%;
      }
    }
    .share-goods-form {
      margin-top: 50px;
      max-width: 500px;
      .goods-pic {
        .pic {
          width: 120px;
          height: 90px;
        }
      }
      .goods-spe {
        .add-spe {
          margin-left: 20px;
        }
      }
      .share-goods-period {
        .period-item {
          width: 500px;
          & + .period-item {
            margin-top: 20px;
          }
          .period-label {
            font-size: 16px;
            font-weight: 700;
          }
          .p-cell {
            .label {
              font-size: 14px;
            }
          }
        }
        .add-period {
          margin-top: 10px;
        }
      }
    }
    .footer-wrap {
      margin-top: 30px;
      text-align: right;
    }
  }
</style>
