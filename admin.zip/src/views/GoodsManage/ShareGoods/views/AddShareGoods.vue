<template>
  <edit-share-goods></edit-share-goods>
</template>

<script>
import EditShareGoods from '../components/EditShareGoods'

export default {
  components: {EditShareGoods}
};
</script>

<style scoped>

</style>
