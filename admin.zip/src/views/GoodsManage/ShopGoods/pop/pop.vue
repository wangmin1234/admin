<template>
  <el-dialog 
  class="edit-gategory-dialog"
  :visible.sync="showDialog"
  :close-on-click-modal="false"
  :show-close="false"
  :close-on-press-escape='false'
  width="36%"
  :title="title"
  >
    <!-- 添加编辑分类 -->
    <el-form class="gategory-form" v-if="mode === 1" :model="gategory" label-width="100px" label-position="left" ref="gategoryForm">
      <el-form-item label="分类名称" prop="gategoryName" :rules="[
        {
          required: true,
          message: '输入正确的分类名称（10字以内）',
          trigger: 'blur',
          max: 10
        }
      ]">
        <el-input v-model="gategory.gategoryName" placeholder="分类名称10字以内"></el-input>
      </el-form-item>
      <el-form-item label="分类描述" prop="gategoryDesc" :rules="[
        {
          message: '输入正确的分类描述（40字）',
          max: 40,
          trigger: 'blur'
        }
      ]">
        <el-input v-model="gategory.gategoryDesc" placeholder="分类描述40字以内"></el-input>
      </el-form-item>
    </el-form>

    <!-- 更新商品描述信息 -->
    <el-form v-if="mode === 2" class="update-goods-form" :model="goods" ref="goodsForm">
      <el-form-item prop="desc" :rules="[
        {
          max: 200,
          message: '商品描述信息不能超过200字'
        }
      ]">
        <div class="goods-desc-wrap">
          <el-input type="textarea" v-model="goods.desc" placeholder="输入描述信息" :rows="8" resize="none" :show-word-limit="true" maxlength="200"></el-input>
        </div>
      </el-form-item>
    </el-form>

    <div slot="footer">
      <el-button type="primary" size="small" @click="confirm">确认</el-button>
      <el-button type="primary" plain size="small" @click="cancel">取消</el-button>
    </div>
  </el-dialog>
</template>

<script>
export default {
  data() {
    return {
      // 1 分类操作 2修改商品描述信息操作
      mode: 0,
      title: '',
      gategory: {
        gategoryName: '',
        gategoryDesc: ''
      },
      goods: {
        desc: ''
      },
      showDialog: false
    }
  },
  methods: {
    init() {
      this.mode = 0
      this.title = ''
      this.gategory.gategoryName = ''
      this.gategory.gategoryDesc = ''
      this.goods.desc = ''
      this.goods.descWordsNum = 0
      this.resolve = null
      this.reject = null
    },
    confirm() {
      if(this.mode === 1) {
        this.$refs.gategoryForm.validate((valid) => {
          if(valid) {
            this.resolve && this.resolve({...this.gategory})
            this.showDialog = false
            this.init()
          }
        })
      }
      if(this.mode === 2) {
        this.$refs.goodsForm.validate((valid) => {
          if(valid) {
            this.resolve && this.resolve({...this.goods})
            this.showDialog = false
            this.init()
          }
        })
      }
    },
    cancel() {
      this.reject && this.reject()
      this.showDialog = false
      this.init()
    }
  }
};
</script>

<style lang="less">
  .edit-gategory-dialog {
    .el-dialog {
      min-width: 460px;
      .el-dialog__body {
        padding: 15px 20px;
      }
      .el-dialog__footer {
        padding: 0 20px 15px;
      }
      .gategory-form {
        width: 80%;
      }
    }
  }
</style>
