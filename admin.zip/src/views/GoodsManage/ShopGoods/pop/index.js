import Vue from 'vue'
import pop from './pop'

const PopConstructor = Vue.extend(pop)

let instance = null
const getPopInstance = function getInstance() {
  if(instance) {
    return instance
  }
  instance = new PopConstructor({
    el: window.document.createElement('div')
  })
  window.document.body.appendChild(instance.$el)
  return instance
}

// 添加分类
export function addGategory() {
  const ins = getPopInstance()
  return new Promise((resolve, reject) => {
    ins.mode = 1
    ins.title = '添加分类'
    ins.resolve = resolve
    ins.reject = reject
    ins.showDialog = true
  })
}

// 编辑分类
export function updateGategory({ gategoryName, gategoryDesc} = {}) {
  const ins = getPopInstance()
  return new Promise((resolve, reject) => {
    ins.mode = 1
    ins.title = '编辑分类'
    ins.gategory.gategoryName = gategoryName
    ins.gategory.gategoryDesc = gategoryDesc
    ins.resolve = resolve
    ins.reject = reject
    ins.showDialog = true
  })
}

// 编辑描述信息
export function updateGoods({desc} = {}) {
  const ins = getPopInstance()
  return new Promise((resolve, reject) => {
    ins.mode = 2
    ins.title = '编辑描述'
    ins.goods.desc = desc
    ins.resolve = resolve
    ins.reject = reject
    ins.showDialog = true
  })
}