<template>
  <div class="goods-edit-wrap">
    <el-form class="goods-edit-form" :model="goods" label-width="150px" label-position="left" ref="goodsEditForm">
      <h3 class="goods-info-label">基本信息</h3>
      <!-- 商品分类 -->
      <el-form-item label="商品分类" class="goods-gategory" :rules="[{required: true}]">
        <el-select v-model="goods.gategory">
          <el-option label="分类1" value="fenlei1"></el-option>
          <el-option label="分类2" value="fenlei2"></el-option>
        </el-select>
        <el-button class="add-gategory-btn" type="primary" plain @click="addGoodsGategory">添加分类</el-button>
      </el-form-item>
      <!-- 商品平台分类 -->
      <el-form-item label="商品平台分类" :rules="[{required: true}]">
        <el-cascader :options="gategoryPlatOptions" v-model="goods.gategoryPlat"></el-cascader>
      </el-form-item>
      <!-- 商品名称 -->
      <el-form-item label="商品名称" prop="name" :rules="[
        {
          required: true,
          max: 30,
          message: '请输入正确的商品名称（30字以内）'
        }
      ]">
        <el-input v-model="goods.name" placeholder="输入商品名"></el-input>
      </el-form-item>
      <!-- 商品图片 -->
      <el-form-item label="商品图片" class="upload-goods-pic" :rules="[{required: true}]">
        <p class="tip">商品图片尺寸：600x450</p>
        <div class="goods-pic-wrap">
          <span class="icon-add-pic el-icon-plus"></span>
        </div>
      </el-form-item>
      <!-- 商品图文描述 -->
      <el-form-item label="商品图文描述" class="goods-details">
        <p class="tip">建议需要在客户端展示商品的详情的商品填写此项</p>
        <editor v-model="goods.details" height="300px"></editor>
      </el-form-item>

      <h3 class="goods-info-label" style="margin-top: 50px">售卖信息</h3>
      <!-- 商品价格 -->
      <el-form-item label="商品价格" class="goods-price" prop="price" :rules="[
        {
          required: true,
          pattern: /^\d+(\.\d{1,2})?$/,
          message: '输入正确的商品价格'
        }
      ]">
        <p class="tip">最多保留两位小数</p>
        <el-input v-model="goods.price" placeholder="输入商品价格"></el-input>
      </el-form-item>
      <!-- 商品库存 -->
      <el-form-item label="库存" prop="repertory" :rules="[
        {
          required: true,
          pattern: /^\d+$/,
          message: '请填写正确的库存'
        }
      ]">
        <el-input v-model="goods.repertory" placeholder="输入商品库存"></el-input>
      </el-form-item>
      <!-- 设置购买单位 -->
      <el-form-item label="购买单位" prop="unit" :rules="[
        {
          required: true,
          max: 3,
          message: '填写商品购买单位'
        }
      ]">
        <el-input v-model="goods.unit" placeholder="输入商品购买单位"></el-input>
      </el-form-item>
      <!-- 购买数量允许为小数 -->
      <el-form-item label="数量是否允许小数" required>
        <p class="tip">在商品的购买中，是否允许购买数量为小数</p>
        <el-switch v-model="goods.numFloat" active-text="允许" inactive-text="不允许"></el-switch>
      </el-form-item>
      <!-- 商品规格 -->
      <el-form-item label="商品规格/属性" class="goods-spe">
        <div class="spe-wrap" v-for="(item, index) in goods.spe" :key="index">
          <span class="spe">{{item}}</span>
          <span class="icon-close el-icon-circle-close" title="删除规格" @click="goods.spe.splice(index, 1)"></span>
        </div>
        <el-button class="add-spe" type="text" size="mini" @click="addGoodsSpe">添加规格/属性</el-button>
      </el-form-item>
      <!-- 是否支持邮寄 -->
      <el-form-item label="是否支持邮寄" class="express-switch" prop="expressPrice" :rules="[
        {
          pattern: /^((\d+(\.\d{1,2})?)|(empty))$/,
          required: true,
          transform(value) {
            if(!goods.canExpress) {
              return 'empty'
            }
            return value
          },
          message: '输入正确的快递费用',
        }
      ]">
        <el-switch v-model="goods.canExpress" active-text="支持" inactive-text="不支持"></el-switch>
        <el-tooltip content="商品快递费" placement="right" v-if="goods.canExpress">
          <el-input v-model="goods.expressPrice" class="express-price" placeholder="输入快递费用"></el-input>
        </el-tooltip>
      </el-form-item>
      <!-- 是否支持配送 -->
      <el-form-item label="是否支持送货上门" required>
        <p class="tip">商家安排店员或其他人配送</p>
        <el-switch v-model="goods.delivery" active-text="支持" inactive-text="不支持"></el-switch>
      </el-form-item>
      <!-- 是否支持自取 -->
      <el-form-item label="是否支持自取" required>
        <el-switch v-model="goods.oneself" active-text="支持" inactive-text="不支持"></el-switch>
      </el-form-item>
      <!-- 是否支持商品分享 -->
      <el-form-item label="是否支持分享" prop="partnerShareMoney" :rules="[
        {
          required: true,
          message: '输入正确的提成价格',
          pattern: /^((\d+(\.\d{1,2})?)|(empty))$/,
          transform(value) {
            if(!goods.partnerShare) {
              return 'empty'
            }
            return value
          }
        }
      ]">
        <p class="tip">指定该商品能否被合伙人分享赚钱</p>
        <el-switch v-model="goods.partnerShare" active-text="支持" inactive-text="不支持"></el-switch>
        <el-tooltip content="合伙人提成价格" placement="right" v-if="goods.partnerShare">
          <el-input v-model="goods.partnerShareMoney" placeholder="输入合伙人提成价格"></el-input>
        </el-tooltip>
      </el-form-item>
      <!-- 商品包装费 -->
      <!-- 
        商品包装费分两种方式，都是使用packingPrice变量表示
        1. 不开启小件计费： 直接填写最多两位小数的商品包装费 (\d+(\.\d{1,2})?) 使用packingPrice[0]保存
        2. 开启小件计费： 填写n份m元格式的数据，n为非0正整数，m为最多两位小数的包装费，n使用packingPrice[0]， m使用packingPrice[1]， ([1-9]+,\d+(\.\d{1,2})?)
       -->
      <el-form-item label="商品包装费" required prop="packingPrice" class="goods-packing-price" :rules="[
        {
          required: true,
          pattern: /^((\d+(\.\d{1,2})?)|([1-9]+,\d+(\.\d{1,2})?))$/,
          message: '输入正确的商品包装费',
          transform(value) {
            if(!goods.smallBilling) {
              return value[0]
            }
            return value.join(',')
          }
        }
      ]">
        <el-input v-model="goods.packingPrice[0]" v-if="!goods.smallBilling"></el-input>
        <div v-else class="small-biiling">
          <span class="text">每</span>
          <el-input class="s-input" size="mini" v-model="goods.packingPrice[0]"></el-input>
          <span class="text">份商品收取</span>
          <el-input class="s-input" size="mini" v-model="goods.packingPrice[1]"></el-input>
          <span class="text">元</span>
        </div>
        <el-tooltip placement="right">
          <p slot="content">开启小件商品计价后，商品包装费会根据下单商品数量变化。
            <br>
            举例：每 3 个鸭头共用 1 个餐盒，收取包装费1元。填写 每 3 份收取 1 元。
            <br>
            用户购买1~3个鸭头时，收取包装费1元，
            <br>
            用户购买4~6个鸭头时，收取包装费2元，
            <br>
            用户购买7~9个鸭头时，收取包装费3元，以此类推。
          </p>
          <el-checkbox v-model="goods.smallBilling">开启小件计费</el-checkbox>
        </el-tooltip>
      </el-form-item>
    </el-form>
    <div class="footer-action">
      <el-button type="primary">保存并返回</el-button>
      <el-button type="primary">保存并继续新建</el-button>
      <el-button type="warning" plain>取消</el-button>
    </div>
  </div>
</template>

<script>
import Editor from '@/components/Editor'
import {addGategory} from '../pop'

export default {
  components: {Editor},
  data() {
    return {
      goods: {
        gategory: '',
        gategoryPlat: [],
        name: '',
        details: '',
        price: '',
        repertory: '',
        unit: '',
        numFloat: false,
        spe: [],
        canExpress: false,
        expressPrice: '',
        delivery: false,
        oneself: false,
        partnerShare: false,
        partnerShareMoney: '',
        packingPrice: [0, 0],
        smallBilling: false
      },
      gategoryPlatOptions: [
        {
          value: 'fenlei1',
          label: 'fenlei1',
          children: [
            {
              value: 'fenlei2',
              label: 'fenlei2'
            }
          ]
        }
      ]
    }
  },
  methods: {
    addGoodsGategory() {
      addGategory()
    },
    addGoodsSpe() {
      this.$prompt('输入规格/属性（6字以内）', '提示', {
        inputPattern: /^.{1,6}$/,
        inputErrorMessage: '规格/属性格式错误'
      }).then(({value}) => {
        this.goods.spe.push(value)
      }).catch(() => {})
    }
  }
};
</script>

<style scoped lang="less">
  .goods-edit-wrap {
    padding: 15px;
    background-color: #fff;
    max-width: 95%;
    .goods-edit-form {
      width: 600px;
      .goods-info-label {
        font-size: 18px;
        font-weight: 700;
        color: #585a6e;
        margin-bottom: 20px;
      }
      .tip {
        font-size: 12px;
        color: rgb(133, 134, 146);
        margin-bottom: 5px;
      }
      .goods-gategory {
        .add-gategory-btn {
          margin-left: 20px;
        }
      }
      .upload-goods-pic {
        .goods-pic-wrap {
          width: 120px;
          height: 90px;
          background-color: rgb(246, 246, 246);
          cursor: pointer;
          color: rgb(133, 134, 146);
          .icon-add-pic {
            display: inline-block;
            width: 100%;
            height: 100%;
            font-size: 28px;
            text-align: center;
            line-height: 90px;
          }
        }
      }
      .goods-details {
        width: 1200px;
      }
      .goods-price {
        width: 300px;
      }
      .goods-spe {
        .spe-wrap {
          position: relative;
          display: inline-block;
          margin-right: 10px;
          .spe {
            font-size: 12px;
            color: #fff;
            background-color: #409EFF;
            padding: 3px 8px;
            border-radius: 30px;
            line-height: 20px;
          }
          .icon-close {
            font-size: 14px;
            position: absolute;
            right: -6px;
            top: 5px;
            cursor: pointer;
          }
        }
        
      }
      .express-switch {
        .express-price {
          margin-top: 10px;
        }
      }
      .goods-packing-price {
        .small-biiling {
          .text {
            display: inline-block;
            font-size: 12px;
            margin: 0 3px;
          }
          .s-input {
            display: inline-block;
            width: 60px;
          }
        }
      }
    }
    .footer-action {
      margin-top: 50px;
      text-align: right;
      padding-bottom: 30px;
    }
  }
</style>
