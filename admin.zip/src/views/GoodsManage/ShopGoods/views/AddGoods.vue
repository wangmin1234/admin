<template>
  <goods-edit></goods-edit>
</template>

<script>
import GoodsEdit from '../components/GoodsEdit'

export default {
  data() {
    return {}
  },
  components: {GoodsEdit}
};
</script>
