<template>
  <div class="shop-goods-wrap">
    <div class="top-action clearfix">
      <div class="btn-area">
        <el-button class="add-goods-btn" type="primary" size="small" @click="addShopGoods">新建商品</el-button>
      </div>
      <!-- <div class="search-area">
        <el-input v-model="seachText" placeholder="输入商品名称" clearable size="small" prefix-icon="el-icon-search"></el-input>
      </div> -->
    </div>

    <div class="tabs-wrap">
      <el-tabs v-model="activeName">
        <el-tab-pane label="全部 122" name="0"></el-tab-pane>
        <el-tab-pane label="售卖中 122" name="1"></el-tab-pane>
        <el-tab-pane label="已下架 0" name="2"></el-tab-pane>
        <el-tab-pane label="已售完 0" name="3"></el-tab-pane>
      </el-tabs>
    </div>
    <div class="goods-display-wrap clearfix">
      
      <sticky class="category-wrap" className="category-sticky-inner">
        <!-- 添加分类 -->
        <el-button class="add-cate-btn" plain type="primary" icon="el-icon-plus" size="small" @click="addGoodsGategory">添加分类</el-button>
        <draggable class="category" :animation="150">
          <div class="cate-item" v-for="item in 5" :key="item" :class="{active: item === 1}">
            <span class="cate-title">本店特色<span class="cate-num">(10)</span></span>
            <el-tooltip effect="dark" content="编辑分类" placement="top">
              <span class="icon-edit el-icon-setting"></span>
            </el-tooltip>
          </div>
        </draggable>
      </sticky>

      <div class="goods-list-wrap">
        <div class="top-action-wrap">
          <el-checkbox>全选本页</el-checkbox>
          <el-button type="primary" plain size="small">批量上架</el-button>
          <el-button type="primary" plain size="small">批量下架</el-button>
          <el-button type="primary" plain size="small">批量删除</el-button>
        </div>
        <div class="goods-list">
          <div class="goods-item clearfix" v-for="item in 6" :key="item">
            <div class="goods-pic-wrap">
              <img class="goods-pic" :src="$Random.dataImage('600x450', '商品图片')" alt="图片">
              <el-checkbox class="goods-checkbox"></el-checkbox>
              <span class="b-tip">已下架</span>
            </div>
            <div class="goods-item-info clearfix">
              <div class="goods-item-info-details">
                <!-- 商品名 -->
                <x-input class="goods-name" value="小笼包" type="text" bold placeholder="输入商品名"></x-input>
                <!-- 商品价格 库存 -->
                <div class="goods-sell-wrap">
                  <div class="goods-sell-item">
                    <span class="label">￥</span>
                    <x-input class="g-input" type="float" value="12.00"></x-input>
                  </div>
                  <div class="goods-sell-item">
                    <span class="label">库存</span>
                    <x-input class="g-input" type="integer" value="120"></x-input>
                  </div>
                  <div class="goods-sell-item">
                    <span class="label">合伙人提成价格</span>
                    <x-input class="g-input" type="float" value="120"></x-input>
                  </div>
                </div>
                <!-- 销量 -->
                <div class="g-p1">
                  <span class="g-p1-item">月售 12</span>
                </div>
              </div>

              <div class="goods-item-info-o">
                <div class="i-cell">
                  <span class="label">描述</span>
                  <div class="i-text one-hidden" @click="updateGoods">描述信息下克就是贷款卡的撒</div>
                </div>
                <el-button class="edit-spe-btn" type="text" size="small">编辑规格</el-button>
              </div>

              <div class="goods-item-action">
                <el-button type="primary" size="small">上架</el-button>
                <p>
                  <el-button type="text" size="small">编辑</el-button>
                  <el-button type="text" size="small">删除</el-button>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Draggable from 'vuedraggable'
import Sticky from '@/components/Sticky'
import XInput from '@/components/XInput'

import { addGategory, updateGoods} from './pop'

export default {
  data() {
    return {
      activeName: '0',

    }
  },
  components: {Draggable, Sticky, XInput},
  methods: {
    addShopGoods() {
      this.$router.push({name: 'addGoods'})
    },
    addGoodsGategory() {
      addGategory()
    },
    updateGoods() {
      updateGoods({desc: '这是描述信息'})
    }
  }
};
</script>

<style scoped lang="less">
  .shop-goods-wrap {
    background-color: #fff;
    .top-action {
      padding: 10px 15px;
      border-bottom: 1px solid #e9eaf2;
      .btn-area {
        float: left;
      }
      .search-area {
        float: right;
      }
    }
    .tabs-wrap {
      padding: 0 15px;
      .el-tabs__header {
        margin-bottom: 0;
      }
    }
    .goods-display-wrap {
      padding: 0 15px 15px 0;
      .category-wrap {
        float: left;
        width: 210px;
        border-right: 1px solid rgba(222, 222, 222, .5);
        .add-cate-btn {
          margin: 5px 15px 10px;
        }
        .category {
          .cate-item {
            padding: 20px 10px 20px 25px;
            position: relative;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: space-between;
            &.active {
              background-color: #f7f8fa;
              &::before {
                position: absolute;
                content: "";
                width: 3px;
                height: 100%;
                left: 0;
                top: 0;
                background-color: #3f4156;
              }
            }
            &:hover {
              background-color: #f7f8fa;
              .icon-edit {
                display: block;
              }
            }
            .cate-title {
              font-size: 14px;
              .cate-num {
                font-size: 12px;
                color: #858692
              }
            }
            .icon-edit {
              float: right;
              font-size: 14px;
              color: #858692;
              display: none;
              &:hover {
                color: #409EFF;
              }
            }
          }
        }
      }
      .goods-list-wrap {
        overflow: hidden;
        padding: 10px 15px;
        .goods-list {
          min-width: 1000px;
          .goods-item {
            padding: 15px 0;
            border-bottom: 1px solid #e9eaf2;
            cursor: pointer;
            &:hover {
              background-color: #f7f8fa;
              .edit-spe-btn {
                display: block!important;
              }
            }
            .goods-pic-wrap {
              // 600 450
              width: 120px;
              height: 90px;
              margin-right: 15px;
              position: relative;
              float: left;
              .goods-pic {
                width: 100%;
                max-width: 100%;
                max-height: 100%;
              }
              .goods-checkbox {
                position: absolute;
                left: 0;
                top: -10px;
                z-index: 10
              }
              .b-tip {
                width: 100%;
                font-size: 14px;
                padding: 2px 0;
                position: absolute;
                bottom: 0;
                left: 0;
                text-align: center;
                z-index: 10;
                background-color: rgba(0, 0, 0, .5);
                color: #fff;
              }
            }
            .goods-item-info {
              overflow: hidden;
              .goods-item-info-details {
                width: 50%;
                float: left;
                .goods-sell-wrap {
                  background-color: #f7f8fa;
                  padding: 5px 10px;
                  margin-top: 6px;
                  .goods-sell-item {
                    width: auto;
                    display: inline-block;
                    & + .goods-sell-item {
                      margin-left: 10px;
                    }
                    .label {
                      font-size: 12px;
                      margin-right: 5px;
                      line-height: 30px;
                    }
                    .g-input {
                      width: 60px;
                      background-color: #fff;
                    }
                  }
                }
                .g-p1 {
                  margin-top: 5px;
                  .g-p1-item {
                    font-size: 12px;
                    color: #a2a4b3;
                  }
                }
              }
              .goods-item-info-o {
                width: 20%;
                margin-left: 5%;
                float: left;
                .i-cell {
                  width: 100%;
                  display: flex;
                  align-items: center;
                  .label {
                    width: 25%;
                    font-size: 12px;
                    display: inline-block;
                    margin-right: 5%;
                  }
                  .i-text {
                    width: 70%;
                    font-size: 12px;
                    display: inline-block;
                    padding: 3px 6px;
                    border: 1px solid rgba(222, 222, 222, .5);
                    cursor: text;
                    &:hover {
                      border-color: #409EFF;
                    }
                  }
                }
                .edit-spe-btn {
                  margin-top: 10px;
                  display: none;
                }
              }
              .goods-item-action {
                width: 20%;
                margin-left: 5%;
                float: right;
                padding-right: 30px;
                text-align: right;
                & > p {
                  margin-top: 10px;
                }
              }
            }
          }
        }
      }
      
    }
  }
</style>

<style lang="less">
  .shop-goods-wrap {
    .tabs-wrap {
      .el-tabs__item {
        height: 50px;
        line-height: 50px;
      }
      .el-tabs__header {
        margin-bottom: 0;
      }
      .el-tabs__nav-wrap::after {
        height: 1px;
        background-color: rgba(222, 222, 222, .5);
      }
    }
    .goods-display-wrap {
      .category-sticky-inner {
        overflow-y: auto;
        max-height: 100vh;
      }
    }
  }
</style>
