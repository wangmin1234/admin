<template>
  <div class="errPage-container">
    <div class="padding100"></div>
    <el-button icon="arrow-left" class="pan-back-btn" @click="$router.go(-1)">返回</el-button>
    <el-row>
      <el-col :span="12">
        <h1 class="text-jumbo text-ginormous">Oops!</h1>
        <h2>你没有权限访问该内容</h2>
        <ul class="list-unstyled">
          <li>你可以去:</li>
          <li class="link-type">
            <router-link to="/">回首页</router-link>
          </li>
          <li class="link-type"><a href="https://www.taobao.com/" target="__bink">随便看看</a></li>
          <!-- errorType = 1 前后端路由表不一致 -->
          <li class="error" v-if="errorType === 1">如果看到该行红色文字请回忆一哈刚才点击的地方然后反馈。</li>
        </ul>
      </el-col>
      <el-col :span="12">
        <img :src="errGif" width="313" height="428" alt="Girl has dropped her ice cream.">
      </el-col>
    </el-row>
  </div>
</template>

<script>
import errGif from '@/assets/images/401.gif'

export default {
  data() {
    return {
      errorType: 0,
      errGif: errGif + '?' + +new Date(),
    }
  },
  created(){
    this.errorType = this.$route.params.errorType || 0
  }
}
</script>

<style lang="less" scoped>
  .errPage-container {
    width: 800px;
    max-width: 100%;
    margin: 0 auto;
    .padding100 {
      width: 100%;
      height: 100px;
    }
    .pan-back-btn {
      background: #008489;
      color: #fff;
      border: none!important;
    }
    .pan-gif {
      margin: 0 auto;
      display: block;
    }
    .pan-img {
      display: block;
      margin: 0 auto;
      width: 100%;
    }
    .text-jumbo {
      font-size: 60px;
      font-weight: 700;
      color: #484848;
    }
    .list-unstyled {
      font-size: 14px;
      li {
        padding-bottom: 5px;
        &.error {
          color: red;
          font-size: 18px;
          margin-top: 20px;
        }
      }
      a {
        color: #008489;
        text-decoration: none;
        &:hover {
          text-decoration: underline;
        }
      }
    }
  }
</style>
