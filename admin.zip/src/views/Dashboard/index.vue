<template>
  <div class="dashboard-wrap">
    <h1>dashboard</h1>
  </div>
</template>

<script>
export default {
  data() {
    return {
      
    }
  }
};
</script>

<style scoped>
  .dashboard-wrap {
    display: flex;
    justify-content: center;
    align-items: center;
  }
</style>
