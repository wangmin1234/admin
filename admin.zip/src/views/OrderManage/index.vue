<template>
  <div class="order-manage">
    <el-form class="select-wrap" label-width="100px" label-position="left">
      <el-form-item label="订单类型">
        <el-radio-group  v-model="orderType">
          <el-radio :label="1">快递订单</el-radio>
          <el-radio :label="2">配送订单</el-radio>
          <el-radio :label="3">自取订单</el-radio>
          <el-radio :label="4">共享商品订单</el-radio>
        </el-radio-group>
      </el-form-item>
    </el-form>
    <div class="order-content-wrap">
      <!-- 快递订单 -->
      <express-order v-if="orderType === 1"></express-order>
      <!-- 配送订单 -->
      <delivery-order v-if="orderType === 2"></delivery-order>
      <!-- 自取订单 -->
      <invite-order v-if="orderType === 3"></invite-order>
      <!-- 共享商品 -->
      <share-order v-if="orderType === 4"></share-order>
    </div>
  </div>
</template>

<script>
import ExpressOrder from './views/ExpressOrder'
import DeliveryOrder from './views/DeliveryOrder'
import InviteOrder from './views/InviteOrder'
import ShareOrder from './views/ShareOrder'

export default {
  components: { ExpressOrder, DeliveryOrder, InviteOrder, ShareOrder},
  data() {
    return {
      orderType: 4
    }
  }
};
</script>

<style scoped lang="less">
  .order-manage {
    width: 100%;
    .order-content-wrap {
      margin-top: 10px;
    }
  }
</style>
