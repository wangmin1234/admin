<template>
  <div class="express-order-list">
    <div class="express-order-item" v-for="item in 6" :key="item">
      <div class="top-show clearfix">
        <p class="order-time">{{$Random.now()}}</p>
        <p class="order-no">
          <span class="lable">订单号：</span>
          <span class="no">{{$Random.id()}}</span>
        </p>
      </div>
      <!-- 商品详情列表 -->
      <div class="order-goods clearfix">
        <!-- 商品明细 -->
        <div class="goods-items">
          <div class="goods-item clearfix" v-for="item in 2" :key="item">
            <div class="goods-pic-wrap">
              <img class="goods-pic" :src="$Random.dataImage('600x450', 'pic')" alt="图片">
            </div>
            <div class="goods-msg">
              <p class="goods-name">{{$Random.cparagraph(2, 3)}}</p>
              <p class="goods-spe">规格：规格1</p>
            </div>
            <div class="goods-price">
              <p class="price old">
                <span class="small">￥</span>12.00
              </p>
              <p class="price">
                <span class="small">￥</span>9.00
              </p>
              <p class="price-type">（普通会员）</p>
            </div>
            <div class="goods-number">x1</div>
          </div>
        </div>
        <!-- 购买人信息 -->
        <div class="client-info">
          <el-popover placement="bottom" trigger="hover" :width="260">
            <p class="client-name" slot="reference">
              {{$Random.cword(3)}}
              <span class="iconfont icon-yonghu"></span>
            </p>
            <div class="client-info-popover" solt="content">
              <p class="c-p-name">{{$Random.cword(3)}}</p>
              <p>{{$Random.cparagraph(2, 3)}}</p>
              <p>{{$Random.id()}}</p>
            </div>
          </el-popover>
        </div>
        <!-- 订单合计 -->
        <div class="amount">
          <p>总额：￥1200.00</p>
          <p class="line"></p>
          <p>在线支付</p>
        </div>
        <!-- 订单状态和操作 -->
        <div class="status-wrap">
          <p class="status">未付款</p>
          <p>
            <el-button type="text" size="mini">查看详情</el-button>
          </p>
          <p style="margin-top: 10px;">
            <!-- <el-button type="primary" size="mini">发货</el-button> -->
            <el-button type="primary" size="mini">查看物流</el-button>
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  }
};
</script>

<style scoped lang="less">
.express-order-list {
  margin-top: 10px;
  .express-order-item {
    background-color: #fff;
    border: 1px solid #e5e5e5;
    border-bottom: none;
    & + .express-order-item {
      margin-top: 10px;
    }
    .top-show {
      height: 30px;
      line-height: 30px;
      background-color: #eef6ff;
      padding: 0 5px;
      font-size: 12px;
      .order-time {
        float: left;
        margin-right: 20px;
        color: #aaa;
      }
      .order-no {
        float: left;
        .lable {
          color: #aaa;
        }
        .no {
          cursor: pointer;
          &:hover {
            color: #409eff;
          }
        }
      }
    }
    .order-goods {
      width: 100%;
      display: flex;
      .goods-items {
        width: 750px;
        .goods-item {
          width: 100%;
          padding: 12px;
          border-right: 1px solid #e5e5e5;
          border-bottom: 1px solid #e5e5e5;
          .goods-pic-wrap {
            // 600x450
            width: 96px;
            height: 72px;
            float: left;
            margin-right: 12px;
            .goods-pic {
              max-width: 100%;
              max-height: 100%;
            }
          }
          .goods-msg {
            width: 300px;
            float: left;
            .goods-name {
              height: 36px;
              line-height: 18px;
              overflow: hidden;
              color: #333;
              text-align: left;
              font-size: 12px;
            }
            .goods-spe {
              font-size: 12px;
              text-align: left;
              color: #999999;
              margin-top: 10px;
            }
          }
          .goods-price {
            width: 180px;
            float: left;
            text-align: center;
            .price {
              font-size: 14px;
              .small {
                font-size: 12px;
              }
              &.old {
                text-decoration: line-through;
                color: #999999;
              }
            }
            .price-type {
              font-size: 12px;
              color: #333333;
            }
          }
          .goods-number {
            width: 75px;
            float: left;
            font-size: 12px;
            text-align: center;
          }
        }
      }
      .client-info {
        width: 130px;
        border-right: 1px solid #e5e5e5;
        border-bottom: 1px solid #e5e5e5;
        font-size: 12px;
        text-align: center;
        padding: 15px 5px;
        .client-name {
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          padding: 0 5px;
          .icon-yonghu {
            color: #aaaaaa;
          }
        }
      }
      .amount {
        width: 160px;
        padding: 15px 5px;
        color: #aaa;
        font-size: 12px;
        text-align: center;
        border-right: 1px solid #e5e5e5;
        border-bottom: 1px solid #e5e5e5;
        .line {
          width: 86%;
          height: 1px;
          background-color: #e5e5e5;
          margin: 5px auto;
        }
      }
      .status-wrap {
        width: 160px;
        text-align: center;
        padding: 15px 5px;
        border-bottom: 1px solid #e5e5e5;
        font-size: 12px;
        .status {
          color: #aaa;
          margin-bottom: 5px;
        }
      }
    }
  }
}
</style>

<style lang="less">
.client-info-popover {
  font-size: 12px;
  line-height: 1.8;
  .c-p-name {
    font-weight: 700;
  }
}
</style>

