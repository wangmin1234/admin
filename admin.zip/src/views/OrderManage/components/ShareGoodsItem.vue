<template>
  <div class="goods-item-log">
    <!-- 剩余可领取的期数 -->
    <div class="d-top clearfix">
      <div class="goods">
        <img class="goods-pic" :src="$Random.dataImage('650x450')" alt="商品图片">
        <p class="godos-title">{{$Random.cword(5, 10)}}</p>
      </div>
      <el-button class="collapse-btn" type="text" icon="el-icon-caret-top" v-show="!collapse" @click="collapse = !collapse">收起</el-button>
      <el-button class="collapse-btn" type="text" icon="el-icon-caret-bottom" v-show="collapse" @click="collapse = !collapse">展开</el-button>
    </div>
    <div class="get-log-item clearfix">
      <div class="item-left">
        <p class="p1">
          <span class="index">第三期</span>
          <span class="time-interval">有效时间：{{$Random.now()}} - {{$Random.now()}}</span>
        </p>
        <p class="p2">有效期内包含： 浓香甜豆浆3份 每份1杯</p>
        <p class="p3">
          剩余：
          <span class="num">3</span> 份
        </p>
      </div>
      <div class="item-right">
        <!-- <el-button type="primary" size="small">核销</el-button> -->
        <p class="status">已领取</p>
        <p class="time">{{$Random.now()}}</p>
      </div>
    </div>
    <!-- 历史记录 -->
    <el-collapse-transition>
      <div v-show="!collapse">
        <div class="get-log-item clearfix">
          <div class="item-left">
            <p class="p1">
              <span class="index">第三期</span>
              <span class="time-interval">有效时间：{{$Random.now()}} - {{$Random.now()}}</span>
            </p>
            <p class="p2">有效期内包含： 浓香甜豆浆3份 每份1杯</p>
            <p class="p3">
              剩余：
              <span class="num">3</span> 份
            </p>
          </div>
          <div class="item-right">
            <!-- <el-button type="primary" size="small">核销</el-button> -->
            <p class="status">已领取</p>
            <p class="time">{{$Random.now()}}</p>
          </div>
        </div>
        <div class="history-wrap">
          <p class="history-tilte">历史记录</p>
          <div class="get-log-item clearfix" v-for="item in 2" :key="item">
            <div class="item-left">
              <p class="p1">
                <span class="index">第三期</span>
                <span class="time-interval">有效时间：{{$Random.now()}} - {{$Random.now()}}</span>
              </p>
              <p class="p2">有效期内包含： 浓香甜豆浆3份 每份1杯</p>
              <p class="p3">
                剩余：
                <span class="num">3</span> 份
              </p>
            </div>
            <div class="item-right">
              <!-- <el-button type="primary" size="small">核销</el-button> -->
              <p class="status">已领取</p>
              <p class="time">{{$Random.now()}}</p>
            </div>
          </div>
        </div>
      </div>
    </el-collapse-transition>
  </div>
</template>

<script>
export default {
  data() {
    return {
      collapse: true
    }
  }
};
</script>

<style scoped lang="less">
  .goods-item-log {
    margin-top: 20px;
    border-bottom: 1px dashed rgb(222, 222, 222);
    .d-top {
      .goods {
        float: left;
        width: 75%;
        display: flex;
        align-items: center;
        .goods-pic {
          width: 60px;
          height: 45px;
          margin-right: 20px;
        }
        .goods-title {
          font-size: 14px;
        }
      }
      .collapse-btn {
        float: right;
      }
    }
    .get-log-item {
      padding: 10px 0;
      margin-top: 5px;
      .item-left {
        width: 75%;
        float: left;
        .p1 {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          font-size: 12px;
          .index {
            font-size: 16px;
            margin-right: 20px;
          }
        }
        .p2 {
          font-size: 12px;
          margin-top: 8px;
        }
        .p3 {
          font-size: 12px;
          .num {
            color: red;
            font-weight: 700;
          }
        }
      }
      .item-right {
        width: 25%;
        float: left;
        text-align: right;
        .status {
          font-size: 14px;
        }
        .time {
          font-size: 12px;
          margin-top: 10px;
        }
      }
    }
    .history-wrap {
      background-color: #f5f5f6;
      padding: 3px 15px;
      .history-tilte {
        font-size: 14px;
        font-weight: 700;
        margin-top: 10px;
      }
    }
  }
</style>
