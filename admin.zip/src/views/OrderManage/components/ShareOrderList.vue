<template>
  <div class="share-order-list">
    <div class="share-order-item" v-for="(item, index) in 2" :key="item">
      <div class="order-info clearfix">
        <!-- 订单信息 -->
        <div class="order-no-wrap">
          <span class="s1">#</span>
          <span class="num">1</span>
          <span class="arrow"></span>
        </div>
        <div class="order-status">
          <span>进行中</span>
        </div>
      </div>
      <!-- 顾客信息 -->
      <div class="user-info">
        <div class="user-name-wrap">
          <p class="user-name">张（先生）</p>
        </div>
        <div class="u-cell">
          <span class="label">顾客电话</span>
          <span class="u-content">12344441235</span>
        </div>
      </div>
      <!-- 商品信息 -->
      <div class="goods-info">
        <div class="goods-top clearfix">
          <p class="label">商品信息</p>
          <el-button v-show="!(index in spreadStatusList)" class="collapse-btn" type="text" icon="el-icon-caret-bottom" @click="collapseOrderInfo(index)">展开</el-button>
          <el-button v-show="index in spreadStatusList" class="collapse-btn" type="text" icon="el-icon-caret-top" @click="collapseOrderInfo(index)">收起</el-button>
        </div>
        <p class="order-remark">
          <span class="shop-name" title="用户下单时的商家">{{$Random.cword(5, 10)}}</span>
          <span class="shop-phone">联系电话：12309115830</span>
        </p>
        <div class="order-goods-wrap">
          <div class="order-goods-item clearfix" v-for="item in 3" :key="item">
            <div class="goods-item-info clearfix">
              <img class="goods-pic" :src="$Random.dataImage('100x100', 'pic')" alt="商品图片">
              <div class="goods-title">
                <p class="title">{{$Random.ctitle(10, 20)}}</p>
              </div>
            </div>
            <div class="goods-spe">规格1</div>
            <div class="goods-now-price">￥9.00</div>
            <div class="goods-num">x1</div>
            <div class="goods-sum">￥24.00</div>
          </div>
        </div>
      </div>

      <!-- 分享商品周期列表 -->
      <el-collapse-transition>
        <div class="share-goods-period-list" v-show="index in spreadStatusList">
          <!-- 商品 -->
          <p class="label">商品周期使用情况</p>
          <share-goods-item v-for="item in 2" :key="item"></share-goods-item>
        </div>
      </el-collapse-transition>
      
      <!-- 订单编号 -->
      <p class="order-number">{{$Random.now()}}下单&nbsp;&nbsp;|&nbsp;&nbsp;订单编号：{{$Random.id()}}</p>
    </div>
  </div>
</template>

<script>
import ShareGoodsItem from './ShareGoodsItem'

export default {
  components: {ShareGoodsItem},
  data() {
    return {
      spreadStatusList: []
    }
  },
  methods: {
    collapseOrderInfo(orderIndex) {
      const idx = this.spreadStatusList.findIndex(item => item === orderIndex)
      if(idx === -1) {
        this.spreadStatusList.push(orderIndex)
      } else {
        console.log(idx, this.spreadStatusList)
        this.spreadStatusList.splice(idx, 1)
      }
    }
  }
};
</script>

<style scoped lang="less">
.share-order-list {
  margin-top: 10px;
  .share-order-item {
    background-color: #fff;
    padding: 15px;
    & + .share-order-item {
      margin-top: 10px;
    }
    .order-info {
      line-height: 32px;
      padding-right: 15px;
      .order-no-wrap {
        position: relative;
        height: 32px;
        background: #585a6e;
        color: #fff;
        text-align: center;
        margin-right: 20px;
        padding: 0 10px;
        float: left;
        .s1 {
          font-size: 14px;
        }
        .num {
          font-size: 20px;
        }
        .arrow {
          position: absolute;
          right: -9px;
          top: 6px;
          width: 18px;
          height: 18px;
          background: #585a6e;
          transform: rotate(55deg) skewX(25deg);
        }
      }
      .order-status {
        float: right;
        font-size: 14px;
      }
    }
    .user-info {
      padding: 18px 15px;
      border-bottom: 1px dashed rgb(222, 222, 222);
      .user-name-wrap {
        .user-name {
          font-size: 18px;
          color: #555555;
          font-weight: 700;
        }
      }
      .u-cell {
        font-size: 14px;
        margin-top: 10px;
        .label {
          width: 80px;
          color: #999999;
          display: inline-block;
        }
        .u-content {
          display: inline-block;
          color: #555555;
        }
      }
    }
    .goods-info {
      padding: 15px;
      .goods-top {
        .label {
          float: left;
          font-size: 16px;
          font-weight: 700;
        }
        .collapse-btn {
          float: right;
        }
      }
      .order-remark {
        font-size: 14px;
        background-color: #eef6ff;
        border-left: 2px solid #409eff;
        line-height: 34px;
        padding: 0 10px;
        .shop-name {
          margin-right: 20px;
          cursor: default;
        }
        .shop-phone {
          font-size: 12px;
          color: #999999;
        }
      }
      .order-goods-wrap {
        padding: 10px 0;
        border-bottom: 1px dashed rgb(222, 222, 222);
        .order-goods-item {
          line-height: 45px;
          & + .order-goods-item {
            margin-top: 15px;
          }
          .goods-item-info {
            float: left;
            width: 410px;
            .goods-pic {
              width: 60px;
              height: 45px;
              float: left;
              margin-right: 10px;
            }
            .goods-title {
              width: 340px;
              float: left;
              .title {
                overflow: hidden;
                font-size: 14px;
                text-overflow: ellipsis;
                white-space: nowrap;
              }
            }
          }
          .goods-spe {
            font-size: 12px;
            color: #999999;
            width: 100px;
            float: left;
            text-align: center;
          }
          .goods-now-price {
            width: 240px;
            text-align: center;
            font-size: 14px;
            color: #000;
            float: left;
          }
          .goods-num {
            font-size: 14px;
            width: 80px;
            text-align: center;
            float: left;
          }
          .goods-sum {
            font-size: 14px;
            width: 80px;
            text-align: right;
            float: right;
          }
        }
      }
    }
    .share-goods-period-list {
      padding: 0 15px;
      .label {
        font-size: 16px;
        font-weight: 700;
      }
    }
    .order-number {
      padding: 0 15px;
      line-height: 30px;
      font-size: 12px;
      background-color: #f5f5f6;
      color: 999999;
      margin-top: 20px;
    }
  }
}
</style>
