<template>
  <div class="invite-order-wrap">
    <el-form class="select-wrap" label-width="100px" label-position="left">
      <el-form-item label="订单状态">
        <el-radio-group v-model="iCommonOrderStatus">
          <el-radio :label="0">全部</el-radio>
          <el-radio :label="1">待付款</el-radio>
          <el-radio :label="2">待取货</el-radio>
          <el-radio :label="3">待评价</el-radio>
        </el-radio-group>
      </el-form-item>
    </el-form>
    <!-- 普通自取订单列表 -->
    <invite-order-list></invite-order-list>

    <div class="pagination-wrap">
      <el-pagination layout="prev, pager, next" :total="50"></el-pagination>
    </div>
  </div>
</template>

<script>
import InviteOrderList from '../components/InviteOrderList'

export default {
  components: {InviteOrderList},
  data() {
    return {
      iCommonOrderStatus: 0,
      iShareOrderStatus: 0
    }
  }
};
</script>

<style scoped lang="less">
  .invite-order-wrap {
    width: 1200px;
  }
</style>
