<template>
  <div class="express-order">
    <el-form class="select-wrap" label-width="100px" label-position="left">
      <el-form-item label="订单状态">
        <el-radio-group v-model="eOrderType">
          <el-radio :label="0">全部</el-radio>
          <el-radio :label="1">待付款</el-radio>
          <el-radio :label="2">待发货</el-radio>
          <el-radio :label="3">待收货</el-radio>
          <el-radio :label="4">待评价</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="选择日期">
        <el-date-picker v-model="searchDate" type="daterange"
          align="right"
          unlink-panels
          range-separator="-"
          start-placeholder="开始日期"
          end-placeholder="结束日期">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="订单编号">
        <el-input v-model="searchText" placeholder="输入订单编号搜索" style="width: 400px;"></el-input>
      </el-form-item>
    </el-form>
    <express-order-list></express-order-list>
    <div class="pagination-wrap">
      <el-pagination layout="prev, pager, next" :total="50"></el-pagination>
    </div>
    
  </div>
</template>

<script>
import ExpressOrderList from '../components/ExpressOrderList'
export default {
  components: {ExpressOrderList},
  data() {
    return {
      eOrderType: 0,
      searchText: '',
      searchDate: []
    }
  }
};
</script>

<style scoped lang="less">
  .express-order {
    max-width: 1200px;
  }
</style>
