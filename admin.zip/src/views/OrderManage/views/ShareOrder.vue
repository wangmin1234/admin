<template>
  <div class="share-order-wrap">
    <el-form class="select-wrap" label-width="100px" label-position="left">
      <el-form-item label="订单状态">
        <el-radio-group v-model="sOrderType">
          <el-radio :label="0">全部</el-radio>
          <el-radio :label="1">进行中</el-radio>
          <el-radio :label="2">已完成</el-radio>
        </el-radio-group>
      </el-form-item>
    </el-form>

    <share-order-list></share-order-list>

    <div class="pagination-wrap">
      <el-pagination layout="prev, pager, next" :total="50"></el-pagination>
    </div>
  </div>
</template>

<script>
import ShareOrderList from '../components/ShareOrderList'

export default {
  components: {ShareOrderList},
  data() {
    return {
      sOrderType: 0
    }
  }
};
</script>

<style scoped lang="less">
  .share-order-wrap {
    width: 1200px;
  }
</style>
