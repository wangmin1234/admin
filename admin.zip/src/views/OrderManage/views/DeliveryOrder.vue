<template>
  <div class="delivery-order-wrap">
    <el-form class="select-wrap" label-width="100px" label-position="left">
      <el-form-item label="订单状态">
        <el-radio-group v-model="dOrderType">
          <el-radio :label="0">全部</el-radio>
          <el-radio :label="1">待付款</el-radio>
          <el-radio :label="2">待配送</el-radio>
          <el-radio :label="3">待评价</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="选择日期">
        <el-date-picker
          v-model="searchDate"
          type="daterange"
          range-separator="-"
          start-placeholder="开始日期"
          end-placeholder="结束日期">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="订单编号">
        <el-input v-model="searchText" placeholder="输入订单编号搜索" style="width: 400px;"></el-input>
      </el-form-item>
    </el-form>
  
    <delivery-order-list></delivery-order-list>

    <div class="pagination-wrap" style="width: 1200px">
      <el-pagination layout="prev, pager, next" :total="50"></el-pagination>
    </div>
  </div>
</template>

<script>
import DeliveryOrderList from '../components/DeliveryOrderList'

export default {
  components: {DeliveryOrderList},
  data() {
    return {
      dOrderType: 0,
      searchDate: [],
      searchText: ''
    }
  }
};
</script>

<style scoped lang="less">
  .delivery-order-wrap {
    width: 1200px;
  }
</style>
