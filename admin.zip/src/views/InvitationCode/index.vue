<template>
  <!-- 我的邀请码 代理商视角 -->
  <div class="invitation-code-wrap">
    <div class="top-desc">
      <span>我的邀请码：</span>
      <span class="code-can-num">120</span>
      <span class="code-status">可用，</span>
      <span class="code-not-num">1100</span>
      <span class="code-status">已使用</span>
    </div>

    <div class="select-wrap">
      <el-radio-group v-model="codeStatus">
        <el-radio :label="1">未使用</el-radio>
        <el-radio :label="2">已使用</el-radio>
        <el-radio :label="3">搜索</el-radio>
      </el-radio-group>
      <el-input v-if="codeStatus === 3" v-model="seachText" class="search-code" placeholder="搜索编号" clearable size="small" prefix-icon="el-icon-search"></el-input>
    </div>

    <el-table class="code-list" :data="list">
      <el-table-column label="编码" prop="code"></el-table-column>
      <el-table-column label="创建时间" prop="createTime"></el-table-column>
      <el-table-column label="状态">
        <template slot-scope="scope">
          <span v-if="scope.row.status === 0">未使用</span>
          <span v-if="scope.row.status === 1">已使用</span>
        </template>
      </el-table-column>
      <el-table-column label="使用商家名称" prop="useMerchantName"></el-table-column>
      <el-table-column label="使用商家账号" prop="useMerchantId"></el-table-column>
      <el-table-column label="使用时间" prop="useTime"></el-table-column>
    </el-table>

    <!-- 分页 -->
    <div class="pagination-wrap">
      <el-pagination layout="prev, pager, next" :total="50"></el-pagination>
    </div>

  </div>
</template>

<script>
export default {
  data() {
    return {
      codeStatus: 1,
      seachText: '',
      list: []
    }
  },
  created() {
    this.getData()
  },
  methods: {
    getData() {
      this.list = new Array(6).fill(1).map(() => {
        return this.$Mock.mock({
          code: this.$Random.id(),
          createTime: this.$Random.datetime(),
          status: this.$Random.integer(0, 1),
          useMerchantName: this.$Random.name(),
          useMerchantId: this.$Random.id(),
          useTime: this.$Random.datetime()
        })
      })
    }
  }
};
</script>

<style scoped lang="less">
  .invitation-code-wrap {
    .top-desc {
      background-color: #fff;
      padding: 10px 15px;
      .code-can-num {
        font-size: 20px;
        font-weight: 700;
        margin: 0 4px 0 2px;
        color: #409EFF;
      }
      .code-status {
        font-size: 12px;
      }
      .code-not-num {
        font-size: 12px;
        margin-left: 10px;
      }
    }
    .select-wrap {
      .search-code {
        display: inline-block;
        width: 300px;
        margin-left: 30px;
      }
    }
    .code-list {
      margin-top: 20px;
    }
  }
</style>
