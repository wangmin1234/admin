<template>
  <!-- 店内会员 -->
  <div class="shop-members-wrap">
    <h1>店铺会员</h1>
  </div>
</template>

<script>
export default {
  data() {
    return {}
  }
};
</script>

<style scoped lang="less">
  .shop-members-wrap {
    
  }
</style>
