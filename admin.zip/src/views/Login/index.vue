<template>
  <div class="login-container">
    <el-form
      ref="loginForm"
      :model="loginForm"
      class="login-form"
      auto-complete="on"
      label-position="left"
    >
      <h3 class="title">易企盈后台管理登录</h3>
      <el-form-item prop="userName" :rules="[
        {
          required: true,
          message: '输入正确的用户名'
        }
      ]">
        <span class="iconfont icon-user-s"></span>
        <el-input
          v-model="loginForm.userName"
          name="userName"
          type="text"
          auto-complete="on"
          placeholder="请输入用户名"
        />
      </el-form-item>
      <el-form-item prop="password" :rules="[
        {
          required: true,
          message: '输入正确的密码'
        }
      ]">
        <span class="iconfont icon-mima1"></span>
        <el-input
          :type="pwdType"
          v-model="loginForm.password"
          name="password"
          auto-complete="on"
          placeholder="请输入密码"
          @keyup.enter.native="handleLogin"
        />
        <span class="show-pwd" @click="showPwd">
          <span class="iconfont icon-biyan" :class="pwdType === 'password' ? 'icon-biyan' : 'icon-yanjing1'"></span>
        </span>
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          style="width:100%;"
          @click.native.prevent="handleLogin"
        >登录</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import Cookie from 'js-cookie'

export default {
  name: "login",
  data() {
    return {
      loginForm: {
        userName: "admin",
        password: "admin"
      },
      pwdType: "password"
    };
  },
  methods: {
    showPwd() {
      if (this.pwdType === "password") {
        this.pwdType = "";
      } else {
        this.pwdType = "password";
      }
    },
    handleLogin() {
      // 登录
      this.$refs.loginForm.validate(valid => {
        if (!valid) {
          return
        }
        const userName = this.userName
        const password = this.password
        const loading = this.$loading({
          lock: true,
          text: '正在提交',
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.3)'
        });
        // 完成验证 登录
        this.$post('/login', {userName, password})
        .then(({ status, data: res , msg}) => {
          loading.close()
          if(status === 200) {
            Cookie.set('Authorization', res, { expires: 7 })
            this.$router.replace({name: 'bonescreen'})
          }else {
            this.$alert(msg, '登录失败')
          }
        })
        .catch(() => {
          loading.close()
        })
      })
    }
  }
};
</script>

<style rel="stylesheet/less" lang="less">

@bg: #2d3a4b;
@light_gray: #eee;

.login-container {
  .el-input {
    display: inline-block;
    height: 47px;
    width: 85%;
    input {
      background: transparent;
      border: 0px;
      -webkit-appearance: none;
      border-radius: 0px;
      padding: 12px 5px 12px 15px;
      color: @light_gray;
      height: 47px;
      &:-webkit-autofill {
        -webkit-box-shadow: 0 0 0px 1000px #283443 inset !important;
        -webkit-text-fill-color: #fff !important;
      }
    } 
  }
  .el-form-item {
    border: 1px solid rgba(255, 255, 255, 0.1);
    background: rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    color: #454545;
  }
}
</style>

<style rel="stylesheet/less" lang="less" scoped>

@bg: #2d3a4b;
@dark_gray: #889aa4;
@light_gray: #eee;

.login-container {
  position: fixed;
  height: 100%;
  width: 100%;
  background-color: @bg;
  .login-form {
    position: absolute;
    left: 0;
    right: 0;
    width: 520px;
    max-width: 100%;
    padding: 35px 35px 15px 35px;
    margin: 120px auto;
  }
  .iconfont {
    padding: 0 5px 0 10px;
    color: @dark_gray;
    display: inline-block;
    vertical-align: middle;
  }
  .title {
    font-size: 26px;
    font-weight: 400;
    color: @light_gray;
    margin: 0px auto 40px auto;
    text-align: center;
    font-weight: bold;
  }
  .show-pwd {
    position: absolute;
    right: 10px;
    top: 3px;
    font-size: 16px;
    color: @dark_gray;
    cursor: pointer;
    user-select: none;
  }
}
</style>
