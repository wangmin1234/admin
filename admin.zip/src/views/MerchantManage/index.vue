<template>
  <div class="merchant-manage-wrap">
    <div class="merchant-num">
      <span class="p1">我管理区域的商家： </span>
      <span class="m-num">{{$Random.integer(100, 200)}}</span>
      <el-button class="map-btn" type="text">查看商家分布</el-button>
    </div>
    <div class="select-wrap">
      <el-radio-group v-model="operatingStatus">
        <el-radio :label="0">全部</el-radio>
        <el-radio :label="1">正在营业</el-radio>
        <el-radio :label="2">未营业</el-radio>
        <el-radio :label="3">异常停业</el-radio>
      </el-radio-group>
    </div>
    <div class="merchants">
      <div class="merchant-list">
        <div class="items-merchant" v-for="item in 20" :key="item">
          <div class="basic-info clearfix">
            <img class="shop-pic" v-preview :src="$Random.dataImage('750x500', '店铺图片')" alt="图片">
            <div class="info-right">
              <h3 class="shop-title">{{$Random.csentence(10, 20)}}</h3>
              <p class="shop-business-hours">营业时间：{{$Random.datetime()}}</p>
              <p class="shop-business-status">营业状态：正在营业</p>
            </div>
          </div>
          <div class="other-info">
            <div class="item-info clearfix">
              <p class="lable">店铺联系人：</p>
              <p class="content">{{$Random.name()}}</p>
            </div>
            <div class="item-info clearfix">
              <p class="lable">联系人电话：</p>
              <p class="content">{{$Random.id()}}</p>
            </div>
            <div class="item-info clearfix">
              <p class="lable">店铺地址：</p>
              <p class="content">
                <span>{{$Random.county(true)}}&nbsp;&nbsp;</span>
                <el-button type="text" size="mini" @click="openAMap">查看地图</el-button>
              </p>
            </div>
            <div class="item-info clearfix">
              <p class="lable">店铺简介：</p>
              <p class="content">{{$Random.cparagraph()}}</p>
            </div>
            <div class="item-info clearfix">
              <p class="lable">店铺公告：</p>
              <p class="content">{{$Random.cparagraph()}}</p>
            </div>
          </div>
        </div>
      </div>

      <!-- 分页 -->
      <div class="pagination-wrap">
        <el-pagination layout="prev, pager, next" :total="50"></el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      operatingStatus: 0
    }
  },
  methods: {
    openAMap() {
      this.$openAMap({center: [121.59996, 31.197646]})
    }
  }
};
</script>

<style scoped lang="less">
  .merchant-manage-wrap {
    .merchant-num {
      font-weight: 400;
      background-color: #fff;
      padding: 5px 15px;
      .p1 {
        font-size: 16px;
      }
      .m-num {
        font-size: 20px;
        font-weight: 700;
      }
      .map-btn {
        font-size: 12px;
        margin-left: 10px;
      }
    }
    .merchants {
      margin-top: 10px;
      .select-wrap {
        background-color: #fff;
        padding: 10px 15px;
      }
      .merchant-list {
        max-width: 95%;
        .items-merchant {
          width: 100%;
          background-color: #fff;
          padding: 10px 15px;
          margin-top: 10px;
          .basic-info {
            padding-bottom: 10px;
            border-bottom: 1px dashed #BABCCC;
            .shop-pic {
              width: 150px;
              height: 100px;
              float: left;
              margin-right: 20px;
            }
            .info-right {
              overflow: hidden;
              .shop-title {
                font-size: 16px;
                font-weight: 400;
                margin-top: 5px;
              }
              .shop-business-hours {
                margin-top: 8px;
                font-size: 12px;
              }
              .shop-business-status {
                margin-top: 5px;
                font-size: 12px;
              }
            }
          }
          .other-info {
            margin-top: 10px;
            .item-info {
              margin: 10px 0;
              font-size: 14px;
              .lable {
                width: 180px;
                color: #858692;
                float: left;
              }
              .content {
                overflow: hidden;
              }
            }
          }
        }
      }
      .pagination-wrap {
        max-width: 1200px;
      }
    }
  }
</style>
