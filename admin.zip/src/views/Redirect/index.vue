
<script>
export default {
  name: 'redirect',
  beforeCreate(){
    const { route} = this.$route.params
    if(route) {
      this.$router.replace({...route})
    } else {
      this.$router.replace({path: '/'})
    }
  },
  render(h) {
    return h()
  }
}
</script>
