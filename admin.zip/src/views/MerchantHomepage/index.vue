<template>
  <div class="merchant-homepage-wrap">
    <div class="shop-info">
      <img class="shop-pic" :src="$Random.dataImage('100x100', 'touxiang')" alt="店铺图片">
      <!-- 店铺名称 + 店铺编号 -->
      <p>{{$Random.csentence(10)}}({{$Random.id()}})</p>
      <el-popover
        width="500"
        trigger="hover">
        <span class="business-status" slot="reference">正在营业</span>
        <div class="m-business-popover">
          <!-- 营业中 -->
          <p class="status-p1">
            <span>当前餐厅处于设置的营业时间内，正常接受新订单。</span>
            <el-button class="action" type="text">停止营业</el-button>
          </p>

          <!-- 未营业 -->
          <!-- <p class="status-p2">
            <span>当前餐厅处于设置的营业时间内，正常接受新订单。</span>
            <el-button class="action" type="text">开启营业</el-button>
          </p> -->

          <!-- 异常停业 -->
          <!-- <p class="status-p3">
            <span>描述信息</span>
          </p> -->

        </div>
      </el-popover>
    </div>

    <div class="wrap1">
      <div class="data-wrap">
        <p class="data-desc">今日有效订单</p>
        <p class="p1"><span class="b">{{$Random.integer(10, 100)}}</span>单</p>
      </div>
      <div class="data-wrap">
        <p class="data-desc">今日收入</p>
        <p class="p1"><span class="b">{{$Random.float(1000, 10000, 2, 2)}}</span>元</p>
      </div>
      <div class="data-wrap">
        <p class="data-desc">同区域内排名</p>
        <p class="p1"><span class="b">{{$Random.integer(1, 10)}}</span>名</p>
      </div>
    </div>

    <div class="shop-info-detail">
      <!-- 店铺信息 -->
      <div class="s-block">
        <h2 class="top-block clearfix">
          <span class="title">店铺信息</span>
          <el-button class="edit" type="primary" size="mini">申请修改</el-button>
        </h2>
        <el-form class="shop-info-form" :model="shopInfo" label-width="200px" label-position="left">
          <el-formItem label="店铺名称">
            <span>{{$Random.csentence(10)}}</span>
          </el-formItem>
          <el-formItem label="店铺地址">
            <div class="shop-address">
              <span>{{$Random.county(true)}}</span>
              <el-button class="map-action-btn" type="text" @click="openAMap">查看地图</el-button>
            </div>
          </el-formItem>
        </el-form>
      </div>

      <!-- 基本设置 -->
      <div class="s-block">
        <h2 class="top-block clearfix">
          <span class="title">基本设置</span>
          <el-button class="edit" type="primary" size="mini">修改</el-button>
        </h2>
        <el-form class="shop-info-form" :model="shopInfo" label-width="200px" label-position="left">
          <el-formItem label="营业时间">
            <span>9:00 - 10:00</span>
          </el-formItem>
          <el-formItem label="店铺公告">
            <span>{{$Random.csentence(10, 30)}}</span>
          </el-formItem>
          <el-formItem label="店铺简介">
            <span>{{$Random.csentence(20, 40)}}</span>
          </el-formItem>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      shopInfo: {
        shopName: ''
      }
    }
  },
  methods: {
    openAMap() {
      this.$openAMap({center: [121.59996, 31.197646]})
    }
  }
};
</script>

<style scoped lang="less">
  .merchant-homepage-wrap {
    .shop-info {
      display: flex;
      justify-content: flex-start;
      align-items: center;
      padding: 10px 0;
      .shop-pic {
        width: 50px;
        height: 50px;
        margin-right: 10px;
      }
      .business-status {
        margin-left: 10px;
        font-size: 12px;
        cursor: pointer;
        text-decoration: underline;
      }
      
    }
    .wrap1 {
      width: 100%;
      background-color: #fff;
      padding: 20px 100px 30px 100px;
      margin-top: 20px;
      display: flex;
      justify-content: space-between;
      .data-wrap {
        text-align: center;
        .data-desc {
          font-size: 14px;
          color: #585A6E;
        }
        .p1 {
          color: #A2A4B3;
          .b {
            font-size: 34px;
            margin-right: 5px;
            color: #000;
          }
        }
      }
    }
    .shop-info-detail {
      width: 100%;
      margin-top: 20px;
      .s-block {
        background-color: #fff;
        padding: 15px;
        padding-right: 100px;
        & + .s-block {
          margin-top: 20px;
        }
        .top-block {
          width: 100%;
          max-width: 1200px;
          margin-bottom: 20px;
          .title {
            font-size: 14px;
            color: #3F4156;
            margin-right: 10px;
            font-weight: 700;
            float: left;
          }
          .edit {
            float: right;
          }
        }
      }
      .shop-address {
        .map-action-btn {
          font-size: 12px;
          margin-left: 12px;
        }
      }
    }
  }
</style>

<style lang="less">
  .m-business-popover {
    .action {
      margin-left: 20px;
      font-size: 12px;
    }
    .status-p1 {
      .action {
        color: #F56C6C;
      }
    }
    .status-p2 {
      .action {
        color: #67C23A;
      }
    }
  }
</style>
