<template>
  <div class="bill-list-wrap">
    <el-tabs v-model="activeName">
      <el-tab-pane label="已结算账单" name="first"></el-tab-pane>
      <el-tab-pane label="未结算账单" name="second"></el-tab-pane>
    </el-tabs>
    <div class="bill-select-wrap">
      <span class="lable">时间</span>
      <el-date-picker class="data-picker" type="daterange" range-separator="-" start-placeholder="开始日期" end-placeholder="结束日期"></el-date-picker>
      <el-button type="primary" size="small">搜索</el-button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      activeName: 'first'
    }
  }
};
</script>

<style scoped lang="less">
  .bill-list-wrap {
    width: 100%;
    background-color: #fff;
    padding: 20px 30px;
    .bill-select-wrap {
      margin-top: 20px;
      margin-bottom: 20px;
      .lable {
        font-size: 14px;
        color: #858692
      }
      .data-picker {
        margin-left: 20px;
        margin-right: 20px;
      }
    }
  }
</style>
