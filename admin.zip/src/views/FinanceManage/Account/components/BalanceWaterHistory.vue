<template>
  <div class="balance-water-history">
    <div class="top-select-wrap">
      <el-radio-group v-model="radio1">
        <el-radio-button label="今天"></el-radio-button>
        <el-radio-button label="最近7日"></el-radio-button>
        <el-radio-button label="最近一月"></el-radio-button>
        <el-radio-button label="自定义"></el-radio-button>
      </el-radio-group>
      <!-- 时间选择器 -->
      <div class="date-picker-wrap">
        <span class="label">时间</span>
        <el-date-picker v-model="value1" type="daterange" range-separator="-" start-placeholder="开始日期" end-placeholder="结束日期"></el-date-picker>
      </div>
    </div>
    <!-- 表格 -->
    <el-table :data="list">
      <el-table-column label="日期" prop="date"></el-table-column>
      <el-table-column label="类型" prop="type"></el-table-column>
      <el-table-column label="金额（元）">
        <template slot-scope="scope">
          <span style="color: #67C23A">+{{scope.row.moeny}}</span>
        </template>
      </el-table-column>
      <el-table-column label="现有余额">
        <template slot-scope="scope">
          <span style="font-size: 12px;">￥</span>
          <span>{{scope.row.balance}}</span>
        </template>
      </el-table-column>
      <el-table-column label="状态" prop="status"></el-table-column>
      <el-table-column label="操作">
        <template>
          <el-button type="text" size="small">详情</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <div class="pagination-wrap">
      <el-pagination layout="prev, pager, next" :total="50"></el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      radio1: '今天',
      value1: '',
      list: []
    }
  },
  created() {
    const r = this.$Random
    this.list = new Array(10).fill(1).map(() => {
      return this.$Mock.mock({
        date: r.now(),
        type: '余额提现',
        moeny: r.float(10, 200, 2, 2),
        balance: r.float(200, 300, 2, 2),
        status: '交易成功'
      })
    })
  }
};
</script>

<style scoped lang="less">
  .balance-water-history {
    width: 100%;
    margin-top: 10px;
    .top-select-wrap {
      margin-bottom: 30px;
      .date-picker-wrap {
        margin-left: 20px;
        display: inline-block;
        .label {
          font-size: 14px;
          margin-right: 10px;
        }
      }
    }
  }
</style>
