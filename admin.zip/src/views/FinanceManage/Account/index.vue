<template>
  <div class="balance-water-wrap">
    <div class="balance-wrap">
      <!-- 店铺信息 -->
      <div class="shop-info clearfix">
        <div class="shop-pic-wrap">
          <img class="shop-pic" :src="$Random.dataImage('750x500', 'pic')" alt="图片">
        </div>
        <p class="shop-name">{{$Random.cword(5, 10)}}</p>
      </div>
      <!-- 可提现余额 -->
      <div class="can-withdraw-wrap">
        <p class="label">可提现余额</p>
        <div class="moeny-wrap clearfix">
          <p class="moeny">
            <span class="unit">￥</span>
            <span class="integer">10</span>
            <span class="decimal">.20</span>
          </p>
          <el-button type="primary" size="small" @click="withdrawHandle">提现</el-button>
          <el-button type="primary" plain size="small" @click="rechargeHandle">充值</el-button>
        </div>
      </div>
    </div>

    <div class="balance-water">
      <el-tabs v-model="activeName">
        <el-tab-pane label="余额流水记录" name="first">
          <balance-water-history></balance-water-history>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script>
import BalanceWaterHistory from './components/BalanceWaterHistory'
import {recharge, withdraw} from './pop'

export default {
  components: {BalanceWaterHistory},
  data() {
    return {
      activeName: 'first'
    }
  },
  methods: {
    withdrawHandle() {
      withdraw()
    },
    rechargeHandle() {
      recharge()
    }
  }
};
</script>

<style scoped lang="less">
  .balance-water-wrap {
    width: 100%;
    .balance-wrap {
      width: 100%;
      background-color: #fff;
      padding-right: 50px;
      padding: 20px 30px;
      .shop-info {
        width: 100%;
        display: flex;
        align-items: flex-end;
        .shop-pic-wrap {
          width: 75px;
          height: 50px;
          margin-right: 20px;
          .shop-pic {
            max-width: 100%;
            max-height: 100%;
          }
        }
        .shop-name {
          font-size: 16px;
          padding-bottom: 3px;
        }
      }
      .can-withdraw-wrap {
        margin-top: 20px;
        .label {
          color: #858692;
          font-size: 14px;
        }
        .moeny-wrap {
          padding: 10px 0;
          width: 100%;
          display: flex;
          align-items: center;
          .moeny {
            color: #585a6e;
            width: 200px;
            float: left;
            margin-right: 50px;
            .unit {
              font-size: 18px;
            }
            .integer {
              font-size: 30px;
            }
            .decimal {
              font-size: 24px;
            }
          }
        }
      }
    }
    .balance-water {
      background-color: #fff;
      margin-top: 10px;
      padding: 20px 30px;
    }
  }
</style>
