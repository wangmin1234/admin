import Vue from 'vue'
import pop from './pop'

const PopConstructor = Vue.extend(pop)

let instance = null
const getPopInstance = function getInstance() {
  if (instance) {
    return instance
  }
  instance = new PopConstructor({
    el: window.document.createElement('div')
  })
  window.document.body.appendChild(instance.$el)
  return instance
}

// 充值
export function recharge() {
  const ins = getPopInstance()
  return new Promise((resolve, reject) => {
    ins.mode = 1
    ins.title = '充值'
    ins.resolve = resolve
    ins.reject = reject
    ins.showDialog = true
  })
}

// 提现
export function withdraw() {
  const ins = getPopInstance()
  return new Promise((resolve, reject) => {
    ins.mode = 2
    ins.title = '余额提现'
    ins.resolve = resolve
    ins.reject = reject
    ins.showDialog = true
  })
}