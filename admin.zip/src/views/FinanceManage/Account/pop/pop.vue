<template>
  <el-dialog 
  :title="title" 
  :visible.sync="showDialog"
  width="600px"
  :close-on-click-modal="false"
  :close-on-press-escape="false"
  >
    <!-- 账户充值 -->
    <el-form class="account-recharge-form" :model="accountRecharge" label-width="100px" ref="accountRechargeForm" v-if="mode === 1">
      <el-form-item label="当前余额">
        <span>￥12.00</span>
      </el-form-item>
      <el-form-item label="充值金额" prop="money" :rules="[
        {
          required: true,
          message: '输入正确的充值金额',
          pattern: /^[1-9]\d*(\.\d{1,2})?$/
        }
      ]">
        <el-input v-model="accountRecharge.money" placeholder="输入充值金额"></el-input>
      </el-form-item>
      <el-form-item label="">
        <el-radio-group v-model="accountRecharge.selectMoneyType" @change="selectMoney">
          <el-radio :label="0">其它</el-radio>
          <el-radio :label="1">100元</el-radio>
          <el-radio :label="2">500元</el-radio>
          <el-radio :label="3">1000元</el-radio>
        </el-radio-group>
      </el-form-item>
      <div class="a-r-actions">
        <el-button type="primary" size="small" @click="toRecharge">充值</el-button>
        <el-button type="primary" plain size="small" @click="cancel">取消</el-button>
      </div>
    </el-form>

    <!-- 账户提现 -->
    <el-form class="account-withdraw-form" :model="accountWithdraw" label-width="100px" ref="accountWithDrawForm" v-if="mode === 2">
      <el-form-item label="提现金额" prop="money" :rules="[
        {
          required: true,
          message: '输入正确的提现金额',
          pattern: /^[1-9]\d*(\.\d{1,2})?$/
        }
      ]">
        <el-input v-model="accountWithdraw.money" placeholder="输入金额"></el-input>
        <p><span style="margin-right: 20px;">可提现余额：0.00</span><el-button type="text" size="small">全部提现</el-button></p>
      </el-form-item>
      <el-form-item label="选择银行" prop="bankName" :rules="[
        {
          required: true,
          message: '请选择银行'
        }
      ]">
        <el-select v-model="accountWithdraw.bankName" placeholder="请选择">
          <el-option label="name" value="中国工商银行"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="银行卡号" prop="bankNo" :rules="[
        {
          required: true,
          message: '请填写正确的银行卡号',
          pattern: /^[1-9](\d{14}|\d{18})$/
        }
      ]">
        <el-input v-model="accountWithdraw.bankNo" placeholder="输入银行卡号"></el-input>
      </el-form-item>
      <div class="a-r-actions">
        <el-button type="primary" size="small" @click="toRecharge">充值</el-button>
        <el-button type="primary" plain size="small" @click="cancel">取消</el-button>
      </div>
    </el-form>
  </el-dialog>
</template>

<script>
export default {
  data() {
    return {
      // 1 充值  2 提现
      mode: 0,
      title: '',
      showDialog: true,
      accountRecharge: {
        money: '',
        selectMoneyType: 0
      },
      accountWithdraw: {
        money: '',
        bankName: '',
        bankNo: ''
      }
    }
  },
  methods: {
    init() {
      this.mode = 0
      this.title = ''
      this.showDialog = false

      this.accountRecharge.money = ''
      this.accountRecharge.selectMoneyType = 0
    },
    selectMoney(val) {
      let money = 0
      switch(val) {
        case 0:
          money = 0
          break
        case 1:
          money = 100
          break
        case 2:
          money = 500
          break
        case 3:
          money = 1000
          break
      }
      this.accountRecharge.money = money
    },
    toRecharge() {
      this.$refs.accountRechargeForm.validate((valid) => {
        if(valid) {
          // ...
          this.init()
        }
      })
    },
    cancel() {
      this.init()
    }
  }
};
</script>

<style lang="less">
  .account-recharge-form,
  .account-withdraw-form {
    .a-r-actions {
      margin-top: 10px;
      text-align: right
    }
  }
</style>
