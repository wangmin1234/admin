<template>
  <div class="finance-index">
    <div class="finance-base-info clearfix">
      <!-- 余额 -->
      <div class="left-wrap">
        <!-- 店铺信息 -->
        <div class="shop-info clearfix">
          <div class="shop-pic-wrap">
            <img class="shop-pic" :src="$Random.dataImage('750x500', 'pic')" alt="图片">
          </div>
          <p class="shop-name">{{$Random.cword(5, 10)}}</p>
        </div>
        <!-- 可提现余额 -->
        <div class="can-withdraw-wrap">
          <p class="label">可提现余额</p>
          <div class="moeny-wrap clearfix">
            <p class="moeny">
              <span class="unit">￥</span>
              <span class="integer">10</span>
              <span class="decimal">.20</span>
            </p>
            <el-button class="widthdraw" type="primary" size="small">提现</el-button>
          </div>
        </div>
      </div>

      <!-- 余额流水 -->
      <div class="right-wrap">
        <div class="title-box">
          <h4 class="title">最近余额流水</h4>
          <router-link :to="{name: 'balanceWater'}">
            <el-button type="text" size="small">查看余额流水</el-button>
          </router-link>
        </div>
        <ul class="water-list">
          <li class="w-item" v-for="item in 4" :key="item">
            <span class="w-time">{{$Random.now()}}</span>
            <span class="w-type">余额提现</span>
            <span class="w-sum">
              <span class="change">-64.00 元</span>
              <span class="remain"> / 余额 10.00 元</span>
            </span>
          </li>
        </ul>
      </div>
    </div>
    <!-- 账单信息 -->
    <div class="bill-info-wrap">
      <div class="bill-title-box">
        <h2 class="bill-title">账单信息</h2>
        <router-link :to="{name: 'billList'}">
          <el-button class="" type="text" size="small">全部账单</el-button>
        </router-link>
      </div>

      <el-table :data="billList" border>
        <el-table-column label="时间" prop="time"></el-table-column>
        <el-table-column label="账单金额">
          <template slot-scope="scope">
            <span style="font-size: 12px">￥</span>
            <span>{{scope.row.moeny}}</span>
          </template>
        </el-table-column>
        <el-table-column label="状态" prop="status"></el-table-column>
        <el-table-column label="操作">
          <template>
            <el-button type="text" size="small">详情</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      billList: []
    }
  },
  created() {
    const r = this.$Random
    this.billList = new Array(10).fill(1).map(() => {
      return this.$Mock.mock({
        time: r.now(),
        moeny: r.float(200, 300, 2, 2),
        status: '已结算账单'
      })
    })
  }
};
</script>

<style scoped lang="less">
  .finance-index {
    .finance-base-info {
      width: 100%;
      background-color: #fff;
      .left-wrap {
        width: 40%;
        float: left;
        border-right: 1px solid rgba(222, 222, 222, .6);
        padding-right: 50px;
        padding: 20px 30px;
        .shop-info {
          width: 100%;
          display: flex;
          align-items: flex-end;
          .shop-pic-wrap {
            width: 75px;
            height: 50px;
            margin-right: 20px;
            .shop-pic {
              max-width: 100%;
              max-height: 100%;
            }
          }
          .shop-name {
            font-size: 16px;
            padding-bottom: 3px;
          }
        }
        .can-withdraw-wrap {
          margin-top: 20px;
          .label {
            color: #858692;
            font-size: 14px;
          }
          .moeny-wrap {
            padding: 10px 0;
            border-bottom: 1px dashed #e9eaf2;
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            .moeny {
              color: #585a6e;
              width: 200px;
              .unit {
                font-size: 18px;
              }
              .integer {
                font-size: 30px;
              }
              .decimal {
                font-size: 24px;
              }
            }
          }
        }
      }
      .right-wrap {
        width: 60%;
        float: left;
        padding: 20px 30px;
        .title-box {
          margin-bottom: 10px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          .title {
            font-size: 14px;
            font-weight: 700;
            font-weight: 700;
            color: #2a2a2a;
          }
        }
        .water-list {
          .w-item {
            font-size: 14px;
            line-height: 32px;
            .w-type {
              margin-left: 50px;
            }
            .w-sum {
              float: right;
              .remain {
                color: #858692;
              }
            }
          }
        }
      }
    }
    .bill-info-wrap {
      margin-top: 10px;
      padding: 40px 30px;
      background-color: #fff;
      .bill-title-box {
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        .bill-title {
          font-size: 20px;
          font-weight: 700;
        }
      }
    }
  }
</style>
