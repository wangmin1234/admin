<template>
  <keep-alive :include="$store.getters.cacheViews">
    <router-view :key="key"></router-view>
  </keep-alive>
</template>

<script>
export default {
  name: 'financeManage',
  computed: {
    key() {
      return this.$route.fullPath
    }
  }
}
</script>
