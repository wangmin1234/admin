'use strict'

/**
 * 1. 该模块导出了post，postForm，get，分别为发送post json格式的数据请求，发送post 表单格式的请求，发送get请求，使用方法同axios.post()相同。
 * 2. 上述方法返回Promise对象，http请求成功resolve，http请求失败reject
 *    若有用户现在正在填写资料应将数据缓存在本地以便下次打开该页面时读取数据。
 */

import axios from 'axios'
import Cookies from 'js-cookie'
import qs from 'qs'
import router from '@/router'
import nprogress from 'nprogress';

import { MessageBox } from 'element-ui'

const TOKEN = 'Authorization'

// 根据环境获取url，url配置在根目录下的.env文件
const baseURL = process.env.NODE_ENV === 'production'
  ? process.env.VUE_APP_PRO_BASE_URL
  : process.env.VUE_APP_DEV_BASE_URL;

const ins = axios.create({
  baseURL,
  timeout: 5000
})

function request(url, method, data, isFormSubmit, config = {}) {
  let sendData = null
  if (method.toLocaleLowerCase() === 'get' || !isFormSubmit) {
    sendData = data
  } else {
    sendData = qs.stringify(data)
  }
  config.headers = { ...config.headers || {}, [TOKEN]: Cookies.get(TOKEN) }

  return new Promise((resolve, reject) => {
    const requestObj = {
      url,
      method,
      data: sendData,
      ...config
    }
    nprogress.start()
    ins(requestObj).then(({ data: res }) => {
      nprogress.done()
      if (res.status === 403) {
        // 没有登录
        const currentRoute = router.currentRoute
        // 这里直接JSON.stringify(currnetRoute)会报错，具体还没了解清楚。
        window.localStorage.setItem('skipRoute', JSON.stringify({ ...currentRoute }))
        if (name !== 'login') {
          const { location } = window
          location.href = location.origin + '/login'
        }
        return
      }
      if (res.status === 401) {
        // 没有操作权限
        router.push({ name: '401', params: { errorType: 1 } })
        return
      }
      if(res.status !== 200) {
        res.msg = res.msg ? res.msg : '发生预期之外的错误，请稍后再试。'
      }
      resolve(res)
    }).catch(e => {
      nprogress.done()
      reject()
      MessageBox.alert(`
        <p>${url}</p>
        <p>${e.message}</p>
        <p>${new Date().toLocaleString()}</p>
        <p><strong>截图此页面内容进行反馈</strong></p>
      `, '发生预期之外的错误', {
          dangerouslyUseHTMLString: true
        })
    })
  })
}

export function post(url, data, config) {
  return request(url, 'post', data, false, config)
}

export function postForm(url, data, config) {
  return request(url, 'post', data, true, config)
}

export function get(url, data, config) {
  return request(url, 'get', data, null, config)
}

export default function install(Vue) {
  Vue.prototype.$post = post
  Vue.prototype.$post = post
  Vue.prototype.$get = get
}