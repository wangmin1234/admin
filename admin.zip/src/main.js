import Vue from 'vue'
import ElementUI from 'element-ui'
import VueAMap from 'vue-amap'
import _ from 'lodash'

import Reuqest from '@/request'
import Cropper from '@/components/Cropper'
import PreviewImg from '@/components/PreviewImg'
import ErrorAlert from '@/components/ErrorAlert'
import OpenAMap from '@/components/OpenAMap'

import App from './App.vue'
import router from './router/index'
import store from './store/index'

import 'element-ui/lib/theme-chalk/index.css'
import 'nprogress/nprogress.css'
import '@/styles/common.less'
import '@/styles/transform.less'
import '@/styles/global.less'
import '@/assets/font/iconfont.css'

import './directive'
import './utils/errorHandler'

Vue.config.productionTip = false
Vue.prototype.$_ = _
Vue.use(Reuqest)
Vue.use(ElementUI)
// 图片裁剪组件 this.$cropper()
Vue.use(Cropper)
// 图片预览组件 this.$previewImg() 或使用 v-preview指令
Vue.use(PreviewImg)
// 错误弹框提示 this.$errorAlert()
Vue.use(ErrorAlert)
Vue.use(VueAMap)
// 打开地图查看 this.$openAMap()
Vue.use(OpenAMap)
VueAMap.initAMapApiLoader({
  key: '44bfbfbb6898049bd31b80a2dcd2a84e',
});

import '@/mock/mock'

new Vue({
  render: h => h(App),
  router,
  store
}).$mount('#app')
