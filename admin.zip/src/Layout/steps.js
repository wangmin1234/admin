
const steps = [
  {
    element: '.hamburger-container',
    popover: {
      title: '侧边栏按钮',
      description: '点击侧边栏按钮可以折叠/打开左侧的侧边栏。',
      position: 'bottom'
    },
    padding: 0
  },
  {
    element: '.breadcrumb',
    popover: {
      title: '面包屑导航',
      description: '面包屑导航记录着当前页面的位置。',
      position: 'bottom'
    },
    padding: 5
  },
  {
    element: '.screenfull',
    popover: {
      title: '全屏按钮',
      description: '点击全屏按钮可以进入全屏模式让视野更开阔！',
      position: 'left'
    },
    padding: 10
  },
  {
    element: '.h-tags',
    popover: {
      title: '标签栏',
      description: '标签栏记录着访问过的历史页面，点击标签可以快速跳转到相应的页面，也可以对标签进行拖动排序，右键单击标签显示更多选项。',
      position: 'bottom'
    },
    padding: 0
  }
]

export default steps