<template>
  <div class="sidebar" :class="{collapse}">
    <!-- el-scrollbar为elementui滚动组件，没有在文档中写出 -->
    <el-scrollbar wrap-class="scrollbar-wrap">
      <el-menu
        :collapse="collapse"
        class="sidebar-menu"
        :unique-opened="true"
        background-color="#ffffff"
        text-color="#000000"
        active-text-color="#409EFF"
        :default-active="$route.name"
        @select="selectHandle"
      >
        <template v-for="item in menuList">
          <!-- 有子节点 -->
          <menu-sub-item v-if="item.children" :key="item.name" :menuItem="item"></menu-sub-item>
          
          <!-- 没有子节点 -->
          <el-menu-item v-else :key="item.name" :index="item.name">
            <template>
              <i :class="item.icon"></i>
              <span slot="title">{{item.title}}</span>
            </template>
          </el-menu-item>
        </template>
      </el-menu>
    </el-scrollbar>
  </div>
</template>

<script>
import {mapGetters} from 'vuex'
import MenuSubItem from './MenuSubItem'

export default {
  name: 'sidebar',
  methods: {
    selectHandle(index){
      this.$router.push({name: index})
    },
    windowResizeHandle() {
      const { innerWidth} = window
      if(innerWidth <= 1200) {
        this.$store.commit('closeSidebar')
      } else {
        this.$store.commit('openSidebar')
      }
    },
    windowScrollHandle() {
      this.$store.commit('closeSidebar')
    }
  },
  computed: {
    ...mapGetters([
      'collapse',
      'menuList'
    ])
  },
  components: {
    MenuSubItem
  },
  created() {
    this.windowResizeHandle()
    window.addEventListener('resize', this.windowResizeHandle)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.windowResizeHandle)
  }
};
</script>

<style lang="less">

.sidebar {
  width: 180px;
  position: fixed;
  top: 0;
  left: 0;
  bottom: 10px;
  right: 0;
  font-size: 0px;
  z-index: 500;
  overflow: hidden;
  background-color: #fff;
  float: left;
  transition:.28s width ease;
  box-shadow: 0 0 6px 0 #E9EAF2;
  &.collapse {
    width: 64px;
  }
  // 重置侧边栏折叠过度效果
  .horizontal-collapse-transition {
    transition: .28s width ease, 0s padding-left ease-in-out, 0s padding-right ease-in-out;
  }
  .el-scrollbar {
    height: 100%;
    .scrollbar-wrap {
      overflow-x: hidden !important;
      height: 100%;
      .sidebar-menu {
        &:not(.el-menu--collapse) {
          width: 180px;
        }
      }
      .el-menu {
        border: none !important;
      }
    }
  }
}
.el-menu-item,
.el-submenu__title {
  &:hover {
    background-color: #FAFBFC!important;
  }
}
</style>
