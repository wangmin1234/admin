<template>
  <el-submenu :index="menuItem.name">
    <!-- 只有最外层才显示icon -->
    <template v-if="isRoot" slot="title">
      <i :class="menuItem.icon"></i>
      <span>{{menuItem.title}}</span>
    </template>
    <span slot="title" v-if="!isRoot">{{menuItem.title}}</span>

    <template v-for="item in menuItem.children">
      <el-menu-item v-if="!item.children" :key="item.name" :index='item.name'>{{item.title}}</el-menu-item>
      <menu-sub-item v-if="item.children" :key="item.name" :index="item.name" :menuItem="item" :isRoot="false"></menu-sub-item>
    </template>

  </el-submenu>
</template>

<script>

export default {
  name: 'MenuSubItem',
  props: {
    menuItem: {
      type: Object,
      default: function(){return {}}
    },
    isRoot: {
      type: Boolean,
      default: function(){return true}
    }
  }

};
</script>