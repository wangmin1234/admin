<template>
  <div class="container-header">
    <!-- 控制侧边栏折叠图标 -->
      <hamburger class="hamburger-container" @toggle-click="$store.commit('openOrCloseSidebar')" :is-active="!$store.state.app.isCollapse"></hamburger>
    <!-- 面包屑导航栏 -->
      <el-breadcrumb class="breadcrumb" separator="/">
        <transition-group name="breadcrumb">
          <el-breadcrumb-item v-for="item in links" :to="{name: item.name}" :key="item.name">
            {{item.meta.title}}
          </el-breadcrumb-item>
        </transition-group>
      </el-breadcrumb>

    <!-- 个人信息及相关操作 -->
    <el-dropdown class="avatar-container" trigger="hover" :show-timeout="0">
      <div class="avatar-wrapper">
        <img src="@/assets/images/404.png" class="user-avatar">
        <i class="el-icon-caret-bottom"/>
      </div>
      <el-dropdown-menu slot="dropdown" class="user-dropdown">
        <el-dropdown-item>基本资料</el-dropdown-item>
        <el-dropdown-item>修改密码</el-dropdown-item>
        <el-dropdown-item divided>
          <span style="display:block;">退出</span>
        </el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>

    <!-- 全屏按钮 -->
    <screenfull class="screenfull"></screenfull>

    <!-- 错误日志 -->
    <el-button class="error-log" type="danger" v-show="errorNum !== 0" @click.native="sendError">
      <span class="iconfont icon-pachong-"></span>
      <!-- max 99 -->
      <span class="tag">{{errorNum > 99 ? '99+' : errorNum}}</span>
    </el-button>
  </div>
</template>

<script>
import Hamburger from "@/components/Hamburger"
import Screenfull from "@/components/Screenfull"

import {mapGetters} from 'vuex'
import axios from 'axios'

export default {
  data(){
    return {
      links: []
    }
  },
  created(){
    this.getBreadcrumb()
  },
  methods: {
    getBreadcrumb(){
      this.links = this.$route.matched.filter(item => item.name && item.name !== 'default')
    },
    sendError(){
      this.$confirm(`在页面访问过程中记录了<span style="color: red; font-weight: 700"> ${this.errorNum} </span>个错误。`, '提示', {
        confirmButtonText: '提交反馈',
        cancelButtonText: '知道了',
        type: 'info',
        dangerouslyUseHTMLString: true
      }).then(() => {
        axios.post('http://utils.xieaben.com/sendMail', {
          errorLog: this.errorLog,
          mail: '552026566@qq.com'
        })
        this.$store.commit('clearErrorLog')
        this.$message({
          message: '提交成功，感谢您的反馈！',
          type: 'success'
        })
      }).catch(() => {})
    }
  },
  watch: {
    $route(){
      this.getBreadcrumb()
    }
  },
  computed: {
    ...mapGetters([
      'errorNum',
      'errorLog'
    ])
  },
  components: {
    Hamburger,
    Screenfull
  }
};


</script>

<style lang="less">
.container-header {
  height: 50px;
  line-height: 50px;
  border-bottom: 1px solid #e6e6e6;
  position: relative;
  overflow: hidden;
  background-color: #fff;
  .hamburger-container {
    overflow: hidden;
    float: left;
    padding: 0 10px;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center
  }
  .breadcrumb {
    line-height: 50px;
    margin-left: 20px;
    float: left;
    .b-link {
      display: inline-block;
    }
  }

  .avatar-container {
    height: 50px;
    display: inline-block;
    position: absolute;
    right: 35px;
    .avatar-wrapper {
      cursor: pointer;
      margin-top: 5px;
      position: relative;
      line-height: initial;
      .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
      }
      .el-icon-caret-bottom {
        position: absolute;
        right: -20px;
        top: 25px;
        font-size: 12px;
      }
    }
  }
  .screenfull {
    position: absolute;
    // space 25px
    right: 100px;
    top: 0px;
    font-size: 18px;
    height: 30px;
    cursor: pointer;
  }
  .error-log {
    position: absolute;
    width: 34px;
    height: 32px;
    top: 9px;
    right: 145px;
    padding: 0;
    .error-icon {
      width: 20px;
      height: 20px
    }
    .tag {
      width: 20px;
      height: 20px;
      background-color: red;
      font-size: 12px;
      color: #fff;
      border-radius: 50%;
      position: absolute;
      right: -9px;
      top: -9px;
      text-align: center;
      line-height: 20px;
      transform: scale(.7);
    }
  }
}
</style>
