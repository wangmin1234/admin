<template>
  <div class="h-tags">
    <!-- 标签 -->
    <tag-views @contextmenu="contextHandle"></tag-views>
    <!-- 右键菜单 -->
    <ul v-show="visible" class="contextmenu"  :style="{left:left+'px',top:top+'px'}" >
      <li v-if="selectedTagIsActive" @click="refreshView(selectedTag)">刷新</li>
      <li v-if="selectedTag.name !== 'dashboard'" @click="$store.commit('closeView', selectedTagIndex)">关闭</li>
      <li @click="$store.commit('closeRightViews', selectedTagIndex)">关闭右侧标签</li>
      <li @click="$store.commit('closeOtherViews' ,selectedTag)">关闭其它标签</li>
      <li @click="$store.commit('closeAllViews')">关闭所有标签</li>
    </ul>
  </div>
</template>

<script>
import TagViews from './TagViews'

export default {
  data() {
    return {
      visible: false,
      top: 0,
      left: 0,
      selectedTag: {},
      selectedTagIsActive: false,
      selectedTagIndex: -1
    }
  },
  components: {TagViews},
  methods: {
    contextHandle(tag, index, isActive, e){
      const menuMinWidth = 105
      const offsetLeft = this.$el.getBoundingClientRect().left
      const offsetWidth = this.$el.offsetWidth
      const maxLeft = offsetWidth - menuMinWidth
      const left = e.clientX - offsetLeft + 15

      if (left > maxLeft) {
        this.left = maxLeft
      } else {
        this.left = left
      }
      this.top = e.clientY - this.$el.offsetTop

      this.visible = true
      this.selectedTag = tag
      this.selectedTagIsActive = isActive
      this.selectedTagIndex = index
    },
    closeMenu() {
      this.visible = false
    },
    refreshView(route){
      this.$store.commit('closeCacheView', route)
      this.$router.replace({name: 'redirect', params: {route}})
    }
  },
  watch: {
    visible(value) {
      if (value) {
        document.body.addEventListener('click', this.closeMenu)
      } else {
        document.body.removeEventListener('click', this.closeMenu)
      }
    }
  }
};
</script>

<style lang="less">
  .h-tags {
    height: 34px;
    background-color: #fff;
    border-bottom: 1px solid #d8dce5;
    white-space: nowrap;
    padding: 0 10px;
    position: relative;
    .contextmenu {
      margin: 0;
      background: #fff;
      z-index: 100;
      position: absolute;
      list-style-type: none;
      padding: 5px 0;
      border-radius: 4px;
      font-size: 12px;
      font-weight: 400;
      color: #333;
      box-shadow: 2px 2px 3px 0 rgba(0, 0, 0, .3);
      li {
        margin: 0;
        padding: 7px 16px;
        cursor: pointer;
        &:hover {
          background: #eee;
        }
      }
    }
  }
</style>
