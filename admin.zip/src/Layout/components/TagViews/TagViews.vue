<template>
  <el-scrollbar ref="scrollContainer" wrap-class="tag-scrollbar">
    <draggable v-model="tags" :animation="150">
      <transition-group name="tag" tag="ul" class="h-tags-wrap" ref="tagsWrap">
        <li 
        v-for="(item, index) in tags" :key="item.name"
        class="tags-item"
        :ref="item.name" 
        :class="{active: item.name === currentRoute.name}"
        :title="item.meta.title"
        v-waves
        @click="$router.push({...item})"
        @contextmenu.prevent="$emit('contextmenu', item, index, item.name === currentRoute.name, $event)"
        >
          <span class="text">{{item.meta.title}}</span>
          <span class="close el-icon-close" v-if="item.name !== 'dashboard'" @click.stop="$store.commit('closeView', index)"></span>
        </li>
      </transition-group>
    </draggable>
  </el-scrollbar>
</template>

<script>
import {mapGetters} from 'vuex'
import Draggable from 'vuedraggable'

export default {
  name: 'tagviews',
  data() {
    return {
      currentRoute: this.$route
    }
  },
  components: {Draggable},
  methods: {
    moveToTarget(val){
      this.$nextTick( () => {
        // 滚动容器宽度外层
        const scrollWidth = this.$refs.scrollContainer.$el.offsetWidth
        // 滚动距离
        const tagScrollbar = document.querySelector('.tag-scrollbar')
        const scrollLeft = tagScrollbar.scrollLeft
        // 当前元素距左边距离
        const target = this.$refs[val.name][0]
        const targetLeft = target.offsetLeft
        const targetWidth = target.offsetWidth
        
        if(targetLeft + targetWidth > scrollWidth + scrollLeft) {
          // 目标元素在右边，向右边滚动
          tagScrollbar.scrollLeft = targetLeft + targetWidth - scrollWidth
        }else if(targetLeft + targetWidth < scrollLeft) {
          // 目标元素在左边，向左边滚动
          tagScrollbar.scrollLeft = targetLeft
        }
      })
      
    }
  },
  watch: {
    $route(val){
      // tag 可以是undefined
      if(val.meta.tag !== false) {
        this.currentRoute = val
        this.moveToTarget(val)
      }
    }
  },
  computed: {
    ...mapGetters([
      'tags'
    ]),
    tags: {
      get(){
        return this.$store.getters.tags
      },
      set(val) {
        this.$store.commit('updateTagViews', val)
      }
    }
  }
};
</script>


<style lang="less">
  .h-tags-wrap {
    height: 34px;
    position: relative;
    .tags-item {
      display: inline-block;
      cursor: pointer;
      height: 26px;
      border-radius: 3px;
      line-height: 26px;
      border: 1px solid #d8dce5;
      color: #495060;
      background: #fff;
      font-size: 12px;
      margin-top: 4px;
      margin-right: 5px;
      position: relative;
      overflow: hidden; 
      padding: 0 8px;
      .text {
        user-select: none;
      }
      .close {
        border-radius: 50%;
        padding: 1px;
        margin-left: 2px;
        &:hover {
          background-color: #b4bccc;
          color: #fff;
        }
      }
      &.active {
        // 使用important避免拖拽的被改变了颜色
        background-color: #42b983!important;
        border-color: #42b983!important;
        background-color: #909399!important;
        border-color: #909399!important;
        color: #fff;
        &::before {
          // 圆点
          content: "";
          background: #fff;
          display: inline-block;
          width: 8px;
          height: 8px;
          border-radius: 50%;
          position: relative;
          margin-right: 3px;
        }
      }
    }
  }
</style>
