<template>
  <div class="layout-wrap">
    <!-- 侧边栏 -->
    <side-bar></side-bar>
    <!-- 右边容器 -->
    <div class="main-container" :class="{'sidebar-collapse' : $store.state.app.isCollapse}">
      <!-- 头部 -->
      <main-header></main-header>
      <!-- 页面标签 -->
      <tag-views></tag-views>
    
      <!-- 正文 -->
      <div class="content-wrap">
        <transition name="fade-transform" mode="out-in">
          <keep-alive :include="$store.getters.cacheViews">
            <router-view :key="key"></router-view>
          </keep-alive>
        </transition>
      </div>
    </div>
    <!-- 回到顶部 -->
    <back-to-top></back-to-top> 
  </div>
</template>

<script>

import Driver from 'driver.js'
import 'driver.js/dist/driver.min.css'
import steps from './steps'
import Cookie from 'js-cookie'

import SideBar from "./components/SideBar";
import MainHeader from "./components/MainHeader";
import TagViews from "./components/TagViews";
import BackToTop from '@/components/BackToTop'

export default {
  name: 'layout',
  mounted(){
    this.showDriver()
  },
  methods: {
    showDriver(){
      const isFirst = Cookie.get('isFirst')
      if(this.$_.isUndefined(isFirst)) {
        const driver = new Driver({
          closeBtnText: '关闭',
          nextBtnText: '下一步',
          prevBtnText: '上一步',
          doneBtnText: '完成',
          onReset(){
            Cookie.set('isFirst', 0, {expires: 90})
          }
        })
        driver.defineSteps(steps)
        driver.start()
      }
    }
  },
  computed: {
    key() {
      return this.$route.fullPath
    }
  },
  components: {
    SideBar,
    MainHeader,
    TagViews,
    BackToTop
  }
};
</script>

<style lang="less">
.layout-wrap {
  position: relative;
  width: 100%;
  height: 100%;
  background-color: #F7F8FA;
  .main-container {
    margin-left: calc( 180px + 10px);
    transition: margin-left 0.28s;
    min-height: 100vh;
    min-width: 1200px;
    background-color: #F7F8FA;
    &.sidebar-collapse {
      margin-left: calc( 64px + 10px);
    }
    .content-wrap {
      padding: 10px 0;
      min-width: 1200px;
    }
  }
}
</style>
