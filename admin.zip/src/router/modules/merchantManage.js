// 代理商视角 商家管理
'use strict'

const route = {
  path: 'merchant',
  name: 'merchantManage',
  component: () => import('@/views/MerchantManage'),
  meta: {
    title: '商家管理',
    keepAlive: true,
    icon: 'el-icon-menu',
    role: ['dev', 'agent']
  }
}

export default route