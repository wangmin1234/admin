// 代理商视角 商家首页
'use strict'

const route = {
  path: 'code',
  name: 'invitationCode',
  component: () => import('@/views/InvitationCode'),
  meta: {
    title: '我的邀请码',
    keepAlive: true,
    icon: 'el-icon-menu',
    role: ['dev', 'agent']
  }
}

export default route