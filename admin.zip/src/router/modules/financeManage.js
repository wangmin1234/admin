
const route = {
  path: 'finance',
  name: 'financeManage',
  component: () => import('@/views/FinanceManage/RouterView'),
  redirect: { name: 'financeIndex'},
  meta: {
    title: '财务管理',
    keepAlive: true,
    icon: 'el-icon-menu',
    role: ['dev', 'merchant']
  },
  children: [
    {
      path: '/index',
      name: 'financeIndex',
      component: () => import('@/views/FinanceManage/Index'),
      meta: {
        title: '对账首页',
        keepAlive: true,
        role: ['dev', 'merchant']
      }
    },
    {
      path: 'balance',
      name: 'balanceWater',
      component: () => import('@/views/FinanceManage/Account'),
      meta: {
        title: '账户管理',
        keepAlive: true,
        role: ['dev', 'merchant']
      }
    },
    {
      path: 'billList',
      name: 'billList',
      component: () => import('@/views/FinanceManage/BillList'),
      meta: {
        title: '账单对账',
        keepAlive: true,
        role: ['dev', 'merchant']
      }
    }
  ]
}

export default route