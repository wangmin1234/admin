// 店内会员管理
const route = {
  path: 'customer',
  name: 'customerManage',
  component: () => import('@/views/CustomerManage/RouterView'),
  redirect: {name: 'shopMembers'},
  meta: {
    title: '顾客管理',
    keepAlive: true,
    icon: 'el-icon-menu',
    role: ['dev', 'merchant']
  },
  children: [
    {
      path: 'shopMembers',
      name: 'shopMembers',
      component: () => import('@/views/CustomerManage/ShopMembers'),
      meta: {
        title: '店内会员',
        keepAlive: true,
        icon: 'el-icon-menu',
        role: ['dev', 'merchant']
      }
    }
  ]
}

export default route