// 商家视角 商品管理
'use strict'

const route = {
  path: 'goods',
  name: 'goodsManage',
  component: () => import('@/views/GoodsManage/RouterView'),
  redirect: {name: 'shopGoods'},
  meta: {
    title: '商品管理',
    keepAlive: true,
    icon: 'el-icon-menu',
    role: ['dev', 'merchant']
  },
  children: [
    {
      path: 'shopGoods',
      name: 'shopGoods',
      component: () => import('@/views/GoodsManage/ShopGoods'),
      meta: {
        title: '店内商品',
        keepAlive: true,
        role: ['dev', 'merchant']
      }
    },
    {
      path: 'addGoods',
      name: 'addGoods',
      component: () => import('@/views/GoodsManage/ShopGoods/views/AddGoods'),
      hidden: true,
      meta: {
        title: '新建商品',
        keepAlive: true,
        role: ['dev', 'merchant']
      }
    },
    {
      path: 'share',
      name: 'shareGoods',
      component: () => import('@/views/GoodsManage/ShareGoods'),
      meta: {
        title: '共享商品',
        keepAlive: true,
        role: ['dev', 'merchant']
      }
    },
    {
      path: 'addShare',
      name: 'addShareGoods',
      component: () => import('@/views/GoodsManage/ShareGoods/views/AddShareGoods'),
      hidden: true,
      meta: {
        title: '新增共享商品',
        keepAlive: true,
        role: ['dev', 'merchant']
      }
    },
    // {
    //   path: 'discountGoods',
    //   name: 'discountGoods',
    //   component: () => import('@/views/GoodsManage/DiscountGoods'),
    //   meta: {
    //     title: '低折扣商品',
    //     keepAlive: true,
    //     role: ['dev', 'merchant']
    //   }
    // },
    // {
    //   path: 'addDiscountGoods',
    //   name: 'addDiscountGoods',
    //   hidden: true,
    //   component: () => import('@/views/GoodsManage/DiscountGoods/views/AddDiscountGoods'),
    //   meta: {
    //     title: '新增低折扣商品',
    //     keepAlive: true,
    //     role: ['dev', 'merchant']
    //   }
    // }
  ]
}

export default route