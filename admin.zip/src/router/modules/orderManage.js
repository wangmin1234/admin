'use strict'
// 订单管理 商家视角

const route = {
  path: 'order',
  name: 'orderManage',
  component: () => import('@/views/OrderManage'),
  meta: {
    title: '订单管理',
    keepAlive: true,
    icon: 'el-icon-menu',
    role: ['dev', 'merchant']
  }
}

export default route