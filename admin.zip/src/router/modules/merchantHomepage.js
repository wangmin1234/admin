// 商家视角 商家首页
'use strict'

const route = {
  path: 'homepage',
  name: 'merchantHomepage',
  component: () => import('@/views/MerchantHomepage'),
  meta: {
    title: '我的店铺',
    keepAlive: true,
    icon: 'el-icon-menu',
    role: ['dev', 'merchant']
  }
}

export default route