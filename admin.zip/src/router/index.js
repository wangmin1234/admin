
'use strict'

import Vue from 'vue'
import VueRouter from 'vue-router'
import { beforeEach, afterEach } from './routeHooks'

import Layout from '@/Layout'

import merchantHomepage from './modules/merchantHomepage'
import merchantManage from './modules/merchantManage'
import invitationCode from './modules/invitationCode'
import goodsManage from './modules/goodsManage'
import orderManage from './modules/orderManage'
import financeManage from './modules/financeManage'
import customerManage from './modules/customerManage'

Vue.use(VueRouter)

/**
 * hidden: true 不在侧边栏显示，不写会显示
 * tag: false 不在tagview中显示，不写或true会显示
 */
const router = new VueRouter({
  mode: 'history',
  linkActiveClass: 'active',
  scrollBehavior: () => ({ y: 0 }),
  routes: [
    { 
      // vue-router会将这里的*放在最后
      path: '*', 
      name: '404', 
      hidden: true, 
      component: () => import('@/views/ErrorPage/404'),
      meta: {
        tag: false
      }
    },
    { 
      path: '/401', 
      name: '401', 
      hidden: true, 
      component: () => import('@/views/ErrorPage/401') ,
      meta: {
        tag: false
      }
    },
    { 
      path: '/bonescreen', 
      name: 'bonescreen', 
      hidden: true, 
      component: () => import('@/views/BoneScreen'),
      meta: {
        tag: false
      }
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('@/views/Login'),
      hidden: true,
      meta: {
        tag: false
      }
    },
    {
      path: '/redirect',
      component: Layout,
      hidden: true,
      meta: {
        tag: false
      },
      children: [
        {
          path: '',
          name: 'redirect',
          component: () => import('@/views/Redirect'),
          meta: {
            tag: false
          },
        }
      ]
    },
    {
      path: '/',
      name: 'default',
      component: Layout,
      hidden: true,
      meta: {
        tag: false
      },
      children: [
        merchantHomepage,
        merchantManage,
        invitationCode,
        goodsManage,
        orderManage,
        financeManage,
        customerManage
      ]
    },

  ]
})

router.beforeEach(beforeEach)
router.afterEach(afterEach)

export default router
