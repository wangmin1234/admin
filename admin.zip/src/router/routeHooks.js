import store from '@/store'
import _ from 'lodash'
import router from '@/router'

const whiteList = ['login', 'bonescreen', '401', '404', 'redirect']

const skip = (next, routeName) => {
  if (router.currentRoute.name === routeName) {
    next({ name: 'redirect', params: { route: { name: routeName}}})
  } else {
    next({ name: routeName})
  }
}

export function beforeEach(to, from, next) {
  if (whiteList.indexOf(to.name) > -1) {
    next()
    return
  }
  if (!store.state.user.userInfo) {
    // 去获取用户信息
    if (to.name !== 'default') {
      window.localStorage.setItem('skipRoute', JSON.stringify({...to}))
    }
    next({ name: 'bonescreen' })
  } else {
    const role = store.state.user.role
    if(to.name === 'default') {
      // 根据身份跳转该身份的首页
      if (role.includes('dev') || role.includes('merchant')) {
        // 商家身份
        skip(next, 'merchantHomepage')
      } else if (role.includes('agent')) {
        // 代理商身份
        skip(next, 'merchantManage')
      } else {
        next({ name: '401' })
      }
    } else {
      // 安全验证，防止访问自己身份外的页面
      const toRouteRole = to.meta.role || []
      if (_.intersection(role, toRouteRole).length !== 0) {
        next()
      } else {
        next({name: '401'})
      }
    }
  }
}

export function afterEach(to) {
  store.commit('updateView', to)
}
