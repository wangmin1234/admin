
import Vue from 'vue'
import { previewImgHandle} from '@/components/PreviewImg'

// 图片预览指令
Vue.directive('preview', {
  inserted(el) {
    if (el.tagName.toLocaleLowerCase() !== 'img') {
      throw new Error('v-preview指令必须存在img标签中')
    }
    el.setAttribute('title', '点击预览')
    el.style.cursor = 'pointer'
    el.addEventListener('click', () => {
      const src = el.getAttribute('src')
      if(!src) {
        return
      }
      previewImgHandle({src})
    })
  }
})