
import './permission'
import './waves'
import './preview'
import './lazy'