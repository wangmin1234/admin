
import Vue from 'vue'
import store from '@/store'

// 权限指令
Vue.directive('permission', {
  inserted(el, binding){
    const authorization = store.getters.authorization
    if(!authorization) {
      return
    }
    if (authorization.indexOf(binding.value) < 0) {
      el.parentNode.removeChild(el)
    }
  }
})