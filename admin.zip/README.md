# admin

## 项目启动
```
git clone ...
yarn install
yarn serve
```
## 项目介绍
采用vue-cli3构建，基于vue + vuex + elementui + axios  
后台搭建思想参考 vue-element-admin

## 项目使用
1. '@'代表src目录

## 图片裁剪组件应用

```js
// 调用
this.$cropper({imgUrl: 'img base64 url', scale: 'scale eg: 750:200'})
.then(({path}) => {
  // 裁剪确认 path为裁剪后base64路径
})
.catch(() => {
  // 取消裁剪
})

```
**注意**

1. `cropper`本身就是使用elementui dialog，所以避免和其他dialog一起使用。
2. 一次只允许调用一次cropper，若在处理过程中调用会导致无法预料的bug，不能配合`Promise.all`使用。

## 图片预览组件应用
```js
this.$previewImg({src: 'src'})
// or 在`img`标签中使用`v-preview`指令
```

## 错误弹框组件应用
```js
this.$errorAlert({msg: 'msg'})
```
**注意**

1. 该弹框没有功能，只做错误展示，一般在后端发生错误时候提示。

## 打开高德地图组件
```js
// 使用的是高德地图 zoom 可选
this.$openAMap({zoom: 12, center: ['经度', '纬度']})
```

## XInput组件
```js
<x-input :store="store" @change="change"></x-input>

// change事件：在点击确定后会触发
// store：在change事件中会从第二个参数带回
```