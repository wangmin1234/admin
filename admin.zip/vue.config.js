
'use strict'
// vue-cli3 中 webpack 配置文件

const path = require('path')

module.exports = {
  chainWebpack: (config) => {
    // 配置@别名
    config.resolve.alias.set('@', path.join(__dirname, 'src'))
  },
  configureWebpack: {
    devtool: 'source-map'
  }
}

